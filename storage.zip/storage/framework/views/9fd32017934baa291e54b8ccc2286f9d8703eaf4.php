
<?php $__env->startSection('title'); ?>
    Nhận đơn hàng
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="single_checkout">
        <div class="container">
            <div class="wrapper">
                <div class="breadcrumb">
                    <ul class="flexitem">
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li>Lịch sử giao dịch</li>
                    </ul>
                </div>
                <?php if(App\Models\OrderDetail::where('status', 2)->where('ship', 0)->count() > 0): ?>
                    <div class="products one cart">
                        <div class="item" style="width: 100%">
                            <form action="<?php echo e(url('confirm')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <table id="cart_table">
                                    <thead>
                                        <tr>
                                            <th>
                                                <button style="border:none; outline:none;font-size:16px;font-weight:600"
                                                    type="submit">Xác nhận </button>
                                            </th>
                                            <th>Sản phẩm</th>
                                            <th>Giá</th>
                                            <th>Số lượng</th>
                                            <th>Tổng tiền</th>
                                            <th>Người nhận</th>
                                            <th>Số điện thoại</th>
                                            <th>Địa chỉ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = App\Models\OrderDetail::where('status', 2)->where('ship',0)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <input type="checkbox" name='ids[]' value="<?php echo e($orderItem->id); ?>">
                                                </td>
                                                <td class="flexitem">
                                                    <?php if($orderItem->sale == 0): ?>
                                                        <div class="thumbnail">
                                                            <a href="<?php echo e(url('detail/' . $orderItem->product_id)); ?>"><img
                                                                    src="<?php echo e($orderItem->product->images->first()->path); ?>"
                                                                    alt="<?php echo e($orderItem->name); ?>"></a>
                                                        </div>
                                                        <div class="content">
                                                            <strong>
                                                                <a href="<?php echo e(url('detail/' . $orderItem->product_id)); ?>"><?php echo e($orderItem->name); ?>

                                                                </a>
                                                            </strong>
                                                            <p style="margin-bottom: 1px">Color:
                                                                <?php echo e($orderItem->color); ?></p>
                                                            <p>Size: <?php echo e($orderItem->size); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="thumbnail">
                                                            <a href="<?php echo e(url('pageoffer/' . $orderItem->product_id)); ?>"><img
                                                                    src="<?php echo e($orderItem->product->images->first()->path); ?>"
                                                                    alt="<?php echo e($orderItem->name); ?>"></a>
                                                        </div>
                                                        <div class="content">
                                                            <strong>
                                                                <a href="<?php echo e(url('pageoffer/' . $orderItem->product_id)); ?>"><?php echo e($orderItem->name); ?>

                                                                </a>
                                                            </strong>
                                                            <p style="margin-bottom: 1px">Color:
                                                                <?php echo e($orderItem->color); ?></p>
                                                            <p>Size: <?php echo e($orderItem->size); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($orderItem->discount): ?>
                                                        <span><?php echo e(number_format($orderItem->price - ($orderItem->discount / 100) * $orderItem->price)); ?>

                                                            VND
                                                        </span>
                                                    <?php else: ?>
                                                        <span>
                                                            <?php echo e(number_format($orderItem->price)); ?>

                                                            VND
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($orderItem->quantity); ?></td>
                                                <td>
                                                    <?php echo e(number_format($orderItem->total_money)); ?> VND
                                                </td>
                                                <td><?php echo e($orderItem->order->fullname); ?></td>
                                                <td><?php echo e($orderItem->order->phone); ?></td>
                                                <td><?php echo e($orderItem->order->address); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <h2 class="search_page"> Hết đơn rồi </h2>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        const dpt_menu = document.querySelectorAll('.dpt_menu');
        const close_menu = document.querySelectorAll('#close_menu');

        for (let i of dpt_menu) {
            i.classList.add('active');
        }
        close_menu.forEach((item) => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                for (let i of dpt_menu) {
                    i.classList.toggle('active');
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\ICT\resources\views/user/design/pageShip.blade.php ENDPATH**/ ?>