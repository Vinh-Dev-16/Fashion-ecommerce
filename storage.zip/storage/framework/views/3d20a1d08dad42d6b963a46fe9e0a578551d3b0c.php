<form method="POST" action="/do-upload" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="image">
    <button type="submit">Upload</button>
</form>

<?php /**PATH D:\Xampp1\htdocs\Fashion\resources\views/upload.blade.php ENDPATH**/ ?>