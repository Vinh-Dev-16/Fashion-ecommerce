
<?php $__env->startSection('title'); ?>
    Tìm kiếm cho <?php echo e($key); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if($searches->count() > 0): ?>
        <h1 class="search_page">Kết quả tìm kiếm cho <?php echo e($key); ?></h1>
        <div class="features">
            <div class="container">
                <div class="wrapper">
                    <div class="column">
                        <div class="sectop flexitem">
                            <h2><span class="circle"></span><span>Kết quả</span></h2>
                        </div>
                        <div class="products main flexwrap">
                            <?php $__currentLoopData = $searches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item page_other">
                                    <div class="media">
                                        <div class="thumbnail object_cover">
                                            <?php if($product->sale == 0): ?>
                                                <a href="<?php echo e(url('detail/' . $product->id)); ?>">
                                                    <img src="<?php echo e($product->images->first()->path); ?>"
                                                        alt="<?php echo e($product->name); ?>">
                                                </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(url('pageoffer/' . $product->id)); ?>">
                                                    <img src="<?php echo e($product->images->first()->path); ?>"
                                                        alt="<?php echo e($product->name); ?>">
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                        <div class="hoverable">
                                            <ul>
                                                <li class="active"><a href=""><i class="ri-heart-line"></i></a></li>
                                                <?php if($product->sale == 0): ?>
                                                    <li><a href="<?php echo e(url('detail/' . $product->id)); ?>"><i
                                                                class="ri-eye-line"></i></a></li>
                                                <?php else: ?>
                                                    <li><a href="<?php echo e(url('pageoffer/' . $product->id)); ?>"><i
                                                                class="ri-eye-line"></i></a></li>
                                                <?php endif; ?>
                                                <li><a href=""><i class="ri-shuffle-line"></i></a></li>
                                            </ul>
                                        </div>
                                        <?php if($product->discount): ?>
                                            <div class="discount circle flexcenter"><span><?php echo e($product->discount); ?>%</span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="content">
                                        <div class="rating">
                                            <?php if(80 *
                                                    ($product->reviews()->pluck('feedbacks.rate')->avg() /
                                                        5) ==
                                                    0): ?>
                                                <div class="stars" style="background-image:none;width:150px">Chưa có
                                                    đánh giá</div>
                                            <?php else: ?>
                                                <div class="stars"
                                                    style="width:<?php echo e(80 *($product->reviews()->pluck('feedbacks.rate')->avg() /5)); ?>px ">
                                                </div>
                                            <?php endif; ?>
                                            <div class="mini_text"><?php echo e($product->reviews->count()); ?> review</div>
                                        </div>
                                        <?php if($product->sale == 0): ?>
                                            <h3 class="main_links"><a
                                                    href="<?php echo e(url('detail/' . $product->id)); ?>"><?php echo e(Illuminate\Support\Str::of($product->name)->words(9)); ?></a>
                                            </h3>
                                        <?php else: ?>
                                            <h3 class="main_links"><a
                                                    href="<?php echo e(url('pageoffer/' . $product->id)); ?>"><?php echo e(Illuminate\Support\Str::of($product->name)->words(9)); ?></a>
                                            </h3>
                                        <?php endif; ?>
                                        <div class="price">
                                            <?php if($product->discount): ?>
                                                <span
                                                    class="current"><?php echo e(number_format(floor($product->price - ($product->price * $product->discount) / 100))); ?>

                                                    VND</span>
                                                <span class="normal mini_text"><?php echo e(number_format($product->price)); ?>

                                                    VND</span>
                                            <?php else: ?>
                                                <span class="current"><?php echo e(number_format($product->price)); ?> VND</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="footer">
                                            <ul class="mini_text">
                                                <li>Cotton, Polyester</li>
                                                <li>100% nguyên chất</li>
                                                <li>Phong cách</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <h1 class="search_page">Không có kết quả tìm kiếm cho <?php echo e($key); ?></h1>
    <?php endif; ?>

    <?php echo e($searches->links('vendor.pagination.default')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        const dpt_menu = document.querySelectorAll('.dpt_menu');
        const close_menu = document.querySelectorAll('#close_menu');

        for (let i of dpt_menu) {
            i.classList.add('active');
        }
        close_menu.forEach((item) => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                for (let i of dpt_menu) {
                    i.classList.toggle('active');
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp1\htdocs\Fashion\resources\views/user/design/search.blade.php ENDPATH**/ ?>