
<?php $__env->startSection('title'); ?>
    Trang payment của <?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="single_checkout">
        <div class="container">
            <div class="wrapper">
                <div class="breadcrumb">
                    <ul class="flexitem">
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li>Thanh toán</li>
                    </ul>
                </div>
                <div class="checkout flexwrap">
                    <div class="item left styled">
                        <h1>Đơn thông tin</h1>
                        <?php $cartCollect = collect($payments);
                        $subTotal = $cartCollect->sum(function ($cartItem) {
                            if (!$cartItem['product']->discount) {
                                return $cartItem['quantity'] * $cartItem['product']->price;
                            } else {
                                return $cartItem['quantity'] * ($cartItem['product']->price - ($cartItem['product']->discount / 100) * $cartItem['product']->price);
                            }
                        });
                        ?>
                        <?php if(App\Models\Information::where('user_id', Auth::user()->id)->first()): ?>
                            <form action="<?php echo e(url('/process-transaction')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php $__currentLoopData = App\Models\Information::where('user_id', Auth::user()->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $information): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p>
                                        <label for="fullname">Full Name<span></span></label>
                                        <input type="text" name="fullname" value="<?php echo e($information->fullname); ?>">
                                    </p>
                                    <p>
                                        <label for="phone">Phone<span></span></label>
                                        <input type="phone" name="phone" value="<?php echo e($information->phone); ?>">
                                    </p>
                                    <p>
                                        <label for="address">Address<span></span></label>
                                        <input type="text" name="address" value="<?php echo e($information->address); ?>">
                                    </p>
                                    <?php if($product->vouchers->count() > 0): ?>
                                        <p>
                                            <label for="voucher">Chọn voucher giảm giá<span></span></label>
                                            <select name="voucher"
                                                style="height: 49px;
                                     width: 106%;"
                                                id="voucher_item">
                                                <option selected>Chọn voucher</option>
                                                <?php $__currentLoopData = $product->vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($voucher->quantity > 0): ?>
                                                        <option value="<?php echo e($voucher->percent); ?>"><?php echo e($voucher->value); ?>

                                                        </option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </p>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <p>
                                    <label for="note">Note<span></span></label>
                                    <input type="text" name="note" id="note">
                                </p>
                                <input type="text" name="user_id" value="<?php echo e(Auth::user()->id); ?>" hidden>
                                <input type="text" name="subtotal" value="<?php echo e($subTotal); ?>" hidden>
                                <p>
                                <div class="primary_checkout"><button class="primary_button"
                                        type="s
                                     ">Thanh toán</button></div>
                                </p>
                            </form>
                        <?php else: ?>
                            <form action="<?php echo e(url('/process-transaction')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <p>
                                    <label for="fullname">Full Name<span></span></label>
                                    <input type="text" name="fullname">
                                </p>
                                <p>
                                    <label for="phone">Phone<span></span></label>
                                    <input type="phone" name="phone">
                                </p>
                                <p>
                                    <label for="address">Address<span></span></label>
                                    <input type="text" name="address">
                                </p>
                                <?php if($product->vouchers->count() > 0): ?>
                                    <p>
                                        <label for="voucher">Chọn voucher giảm giá<span></span></label>
                                        <select name="voucher"
                                            style="height: 49px;
                                     width: 106%;"
                                            id="voucher_item">
                                            <option>Chọn voucher</option>
                                            <?php $__currentLoopData = $product->vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($voucher->quantity > 0): ?>
                                                    <option value="<?php echo e($voucher->percent); ?>"><?php echo e($voucher->value); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </p>
                                <?php endif; ?>
                                <p>
                                    <label for="note">Note<span></span></label>
                                    <input type="text" name="note" id="note">
                                </p>
                                <input type="text" name="user_id" value="<?php echo e(Auth::user()->id); ?>" hidden>
                                <input type="text" name="subtotal" value="<?php echo e($subTotal); ?>" hidden>
                                <p>
                                <div class="primary_checkout"><button class="primary_button"
                                        type="s
                                     ">Thanh toán</button></div>
                                </p>
                            </form>
                        <?php endif; ?>

                    </div>
                    <div class="item right">
                        <h2>Thông tin đơn hàng</h2>
                        <div class="sumary_order ">
                            <div class="sumary_totals">
                                <ul>
                                    <li>
                                        <span>Tổng tiền</span>
                                        <span><?php echo e(number_format($subTotal)); ?> VND</span>
                                    </li>
                                    <li>
                                        <span>Phí ship</span>
                                        <span><?php echo e(number_format(15000)); ?> VND</span>
                                    </li>
                                    <li>
                                        <span>Tax</span>
                                        <span><?php echo e(number_format($subTotal * 0.1)); ?> VND</span>
                                    </li>
                                    <li>
                                        <span>Tổng tất cả</span>
                                        <span class="total"><?php echo e(number_format($subTotal + 15000 + $subTotal * 0.1)); ?>

                                            VND</span>
                                    </li>
                                </ul>
                            </div>
                            <ul class="products mini">
                                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="item">
                                        <div class="thumbnail object_cover">
                                            <img src="<?php echo e($cart_product['image']); ?>"
                                                alt="<?php echo e($cart_product['product']->name); ?>">
                                        </div>
                                        <div class="item_content">
                                            <p><?php echo e($cart_product['product']->name); ?></p>
                                            <span class="price">
                                                <?php if($cart_product['product']->discount): ?>
                                                    <span><?php echo e(number_format($cart_product['quantity'] * ($cart_product['product']->price - ($cart_product['product']->discount / 100) * $cart_product['product']->price))); ?>

                                                        VND
                                                    </span>
                                                <?php else: ?>
                                                    <span><?php echo e(number_format($cart_product['quantity'] * $cart_product['product']->price)); ?></span>
                                                    VND
                                                <?php endif; ?>
                                            </span>
                                            <span>x<?php echo e($cart_product['quantity']); ?></span>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        const dpt_menu = document.querySelectorAll('.dpt_menu');
        const close_menu = document.querySelectorAll('#close_menu');

        for (let i of dpt_menu) {
            i.classList.add('active');
        }
        close_menu.forEach((item) => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                for (let i of dpt_menu) {
                    i.classList.toggle('active');
                }
            });
        })
        let total = document.querySelector('.total');
        console.log(total.text);
        let voucher = document.querySelector('#voucher_item');
        voucher.addEventListener('change', (e) => {
            const res = fetch(`http://127.0.0.1:8000/payment/voucher/${e.target.value}`)
                .then((response) => response.json())
                .then((data) => {
                    showVoucher(data);
                })
                .catch((error) => {
                    console.error("Error:", error);
                });
        })

        function showVoucher(data) {
            console.log(data)
            let total = document.querySelector('.total');
            let ship = (15000 * data.result.length);
            const caculator = data.result.reduce((total, cartItem) => {
                if (data.result[0].product.discount) {
                    return total + cartItem.quantity * (cartItem.product.price - ((cartItem.product
                        .price) * ((cartItem.product.discount) / 100)));
                } else {
                    return total + cartItem.quantity * (cartItem.product.price);
                }
            }, 0);
            if (data.result[0].voucher > 100) {
                total.innerText = ((caculator + (caculator * 0.1) + ship) - data.result[0].voucher).toLocaleString(
                    'vi-VN') + ' VND';
            } else if (data.result[0].voucher > 0 && data.result[0].voucher <= 100) {
                total.innerText = (Math.floor((caculator + (caculator * 0.1) + ship) - ((caculator + (caculator * 0.1) +
                    ship) * (data.result[0].voucher / 100)))).toLocaleString('vi-VN') + ' VND';
            } else {
                total.innerText = (caculator + (caculator * 0.1) + ship).toLocaleString('vi-VN') + ' VND';
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp1\htdocs\Fashion\resources\views/user/design/payment.blade.php ENDPATH**/ ?>