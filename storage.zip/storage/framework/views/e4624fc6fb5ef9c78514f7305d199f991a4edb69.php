
<?php $__env->startSection('title'); ?>
Trang sửa Attribute Value
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="product">
            <div class="card">
                <div class="card-header">
                    <h2 style="font-size:25px;text-align:center;margin:10px 0">SỬA Value</h2>
                </div>
                <div class="card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Form sửa</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form action="<?php echo e(url('admin/value/update/' . $values->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>

                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleName">Tên giá trị thuộc tính</label>
                                <input type="text" class="form-control" id="exampleInputName"
                                    value="<?php echo e($values->value); ?>" name="value">
                            </div>
                            <div class="form-group">
                                <label for="exampleName">Tên attriute </label>
                                <select name="attribute_id" class="form-control" >
                                        <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($values->attribute_id == $attribute->id): ?> selected <?php endif; ?> value="<?php echo e($attribute->id); ?>"><?php echo e($attribute->value); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcumb'); ?>
    <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard.index')); ?>">Home</a></li>
        <li class="breadcrumb-item "><a href="<?php echo e(route('admin.value.index')); ?>">Attribute Value</a></li>
        <li class="breadcrumb-item active">Edit Attribute Value</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\ICT\resources\views/admin/value/edit.blade.php ENDPATH**/ ?>