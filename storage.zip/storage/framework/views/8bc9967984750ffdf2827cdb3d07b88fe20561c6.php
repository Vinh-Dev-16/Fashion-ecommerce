
<?php $__env->startSection('title'); ?>
    Trang giỏ hàng của bạn
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <ul class="notification">
    </ul>
    <?php if(Session::has('cart')): ?>
        <div class="single_cart">
            <div class="container">
                <div class="wrapper">
                    <div class="breadcrumb">
                        <ul class="flexitem">
                            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li>Giỏ hàng của bạn</li>
                        </ul>
                    </div>
                    <div class="page_title">
                        <h1>Giỏ hàng</h1>
                    </div>
                    <div class="products one cart">
                        <div class="flexwrap">
                            <form action="" method="POST" class="form_cart">
                                <?php echo csrf_field(); ?>
                                <div class="item" style="width: 100%">
                                    <table id="cart_table">
                                        <thead>
                                            <tr>
                                                <th>Sản phẩm</th>
                                                <th>Giá</th>
                                                <th>Số lượng</th>
                                                <th>Tổng tiền</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="flexitem">
                                                        <?php if($cart_product['product']->sale == 0): ?>
                                                            <div class="thumbnail">
                                                                <a
                                                                    href="<?php echo e(url('detail/' . $cart_product['product']->id)); ?>"><img
                                                                        src="<?php echo e($cart_product['image']); ?>"
                                                                        alt="<?php echo e($cart_product['product']->name); ?>"></a>
                                                            </div>
                                                            <div class="content">
                                                                <strong>
                                                                    <a
                                                                        href="<?php echo e(url('detail/' . $cart_product['product']->id)); ?>"><?php echo e($cart_product['product']->name); ?>

                                                                    </a>
                                                                </strong>
                                                                <p style="margin-bottom: 1px">Color:
                                                                    <?php echo e($cart_product['color']); ?></p>
                                                                <p>Size: <?php echo e($cart_product['size']); ?></p>
                                                            </div>
                                                        <?php else: ?>
                                                            <div class="thumbnail object_cover">
                                                                <a
                                                                    href="<?php echo e(url('pageoffer/' . $cart_product['product']->id)); ?>"><img
                                                                        src="<?php echo e($cart_product['image']); ?>"
                                                                        alt="<?php echo e($cart_product['product']->name); ?>"></a>
                                                            </div>
                                                            <div class="content">
                                                                <strong>
                                                                    <a
                                                                        href="<?php echo e(url('pageoffer/' . $cart_product['product']->id)); ?>"><?php echo e($cart_product['product']->name); ?>

                                                                    </a>
                                                                </strong>
                                                                <p style="margin-bottom: 1px">Color:
                                                                    <?php echo e($cart_product['color']); ?></p>
                                                                <p>Size: <?php echo e($cart_product['size']); ?></p>
                                                            </div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($cart_product['product']->discount): ?>
                                                            <span><?php echo e(number_format($cart_product['product']->price - ($cart_product['product']->discount / 100) * $cart_product['product']->price)); ?>

                                                            </span>
                                                        <?php else: ?>
                                                            <span>
                                                                <?php echo e(number_format($cart_product['product']->price)); ?>

                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <div class="qty_control flexitem">
                                                            <div style="padding-top: 12px" class="minus"
                                                                onclick="decrement(<?php echo e($cart_product['product']->id); ?>,this)">
                                                                -</div>
                                                            <input type="number" value="<?php echo e($cart_product['quantity']); ?>"
                                                                min="1" max="<?php echo e($cart_product['product']->stock); ?>"
                                                                id="quantity_cart" disabled>
                                                            <div style="padding-top: 12px"
                                                                onclick="increment(<?php echo e($cart_product['product']->id); ?>,<?php echo e($cart_product['product']->stock); ?>,this)"
                                                                class="plus">+</div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <?php if($cart_product['product']->discount): ?>
                                                            <span
                                                                class="price_item"><?php echo e(number_format($cart_product['quantity'] * ($cart_product['product']->price - ($cart_product['product']->discount / 100) * $cart_product['product']->price))); ?>

                                                            </span>
                                                        <?php else: ?>
                                                            </span class="price_item">
                                                            <?php echo e(number_format($cart_product['quantity'] * $cart_product['product']->price)); ?>

                                                            <span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><a
                                                            href="<?php echo e(url('deletecart', ['id' => $cart_product['product']->id])); ?>">
                                                            <i class="ri-close-line"></i>
                                                        </a></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </form>
                            <div class="cart_sumary styled" style="margin-top: 30px">
                                <div class="item" style="width:100%">
                                    <div class="coupon">
                                        <input type="text" placeholder="Hóa đơn">
                                        <button>Áp dụng</button>
                                    </div>
                                    <div class="shipping_rate collapse">
                                        <div class="has_child expand">
                                            <a href="#" class="icon_small">Hóa đơn bao gồm phí ship và tax</a>
                                        </div>
                                        <div class="cart_total">
                                            <?php $cartCollect = collect($cart);
                                            $subTotal = $cartCollect->sum(function ($cartItem) {
                                                if (!$cartItem['product']->discount) {
                                                    return $cartItem['quantity'] * $cartItem['product']->price;
                                                } else {
                                                    return $cartItem['quantity'] * ($cartItem['product']->price - ($cartItem['product']->discount / 100) * $cartItem['product']->price);
                                                }
                                            });
                                            ?>
                                            <table>
                                                <tbody>
                                                    <tr>
                                                        <th>Tổng tiền</th>
                                                        <td class="sub_total"><?php echo e(number_format($subTotal)); ?> </td>
                                                    </tr>
                                                    <tr>
                                                        <th>Phí ship<span class="mini_text">/Product</span></th>
                                                        <td><?php echo e(number_format(15000 * count($cart))); ?> VND</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Tax</th>
                                                        <td class="tax"><?php echo e(number_format($subTotal * 0.1)); ?> VND</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Tổng tất cả</th>
                                                        <td class="total">
                                                            <?php echo e(number_format($subTotal + 15000 * count($cart) + $subTotal * 0.1)); ?>

                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <?php if(Auth::check()): ?>
                                                <a href="<?php echo e(url('checkout')); ?>" class="secondary_button">Check out</a>
                                            <?php else: ?>
                                                <button class="secondary_button"
                                                    onclick="createNoti('Bạn cần phải đăng nhập')"
                                                    style="border:none;outline:none;width:100%">Check out</button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <h1 class="search_page">Bạn chưa có sản phẩm nào trong giỏ hàng</h1>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <?php if(!Auth::check()): ?>
        <script>
            const notifications = document.querySelector('.notification');
            const timer = 3000;
        </script>
    <?php endif; ?>
    <script>
        const dpt_menu = document.querySelectorAll('.dpt_menu');
        const close_menu = document.querySelectorAll('#close_menu');

        for (let i of dpt_menu) {
            i.classList.add('active');
        }
        close_menu.forEach((item) => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                for (let i of dpt_menu) {
                    i.classList.toggle('active');
                }
            });
        })

        // quantity

        function decrement(id, el) {
            let quantity = el.parentElement.querySelector('#quantity_cart');
            let value = parseInt(quantity.value);
            if (value > 1) {
                value -= 1;
                quantity.value = value;
            }
            updateQuantity(id, value, el);
        };

        function increment(id, stock, el) {
            let quantity = el.parentElement.querySelector('#quantity_cart');
            let value = parseInt(quantity.value);
            if (value < stock) {
                value += 1;
                quantity.value = value;
            }
            updateQuantity(id, value, el);
        }

        async function updateQuantity(id, quantity, el) {
            console.log(el);
            const res = await fetch(`http://127.0.0.1:8000/updateQuantity/${id}/${quantity}`)
                .then((response) => response.json())
                .then((data) => {
                    showUpdate(data, el);
                })
                .catch((error) => {
                    console.error("Error:", error);
                });
        }

        function showUpdate(data, el) {
            if (data.cart_item.product.discount) {
                var price = (data.cart_item.product.price - (data.cart_item.product.price * ((data.cart_item.product
                    .discount) / 100))) * data.cart_item.quantity;
                el.parentElement.parentElement.parentElement.querySelector('.price_item').innerText = price.toLocaleString(
                    'vi-VN');
            } else {
                var price = data.cart_item.product.price * data.cart_item.quantity;
                el.parentElement.parentElement.parentElement.querySelector('.price_item').innerText = price.toLocaleString(
                    'vi-VN');
            };

            let ship = (15000 * data.data.length);
            const caculator = data.data.reduce((total, cartItem) => {
                if (data.cart_item.product.discount) {
                    return total + cartItem.quantity * (cartItem.product.price - ((cartItem.product
                        .price) * ((cartItem.product.discount) / 100)));
                } else {
                    return total + cartItem.quantity * (cartItem.product.price);
                }
            }, 0);
            let total = caculator;
            document.querySelector('.tax').innerText = (total * 0.1).toLocaleString('vi-VN') + ' VND';
            document.querySelector('.sub_total').innerText = total.toLocaleString('vi-VN');
            document.querySelector('.total').innerText = (total + (total * 0.1) + ship).toLocaleString('vi-VN');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\ICT\resources\views/user/design/cart.blade.php ENDPATH**/ ?>