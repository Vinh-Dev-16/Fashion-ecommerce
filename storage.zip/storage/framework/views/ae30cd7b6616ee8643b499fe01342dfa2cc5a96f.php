
<?php $__env->startSection('title'); ?>
    Trang tạo thông tin của <?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="form_information">
        <div class="container_information">
            <div class="title">Trang thông tin</div>
            <div class="content">
                <?php if($user->information): ?>
                    <form action="<?php echo e(url('information/update/' . $user->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="user-details">
                            <input type="text" name="user_id" value="<?php echo e($user->information->id); ?>" hidden>
                            <div class="input-box">
                                <span class="details">Full Name</span>
                                <input type="text" value="<?php echo e($user->information->fullname); ?>" name="fullname">
                            </div>
                            <div class="input-box">
                                <span class="details">Phone</span>
                                <input type="tel" name="phone" value="<?php echo e($user->information->phone); ?>">
                            </div>
                            <div class="input-box">
                                <span class="details">Địa chỉ</span>
                                <input type="text" name="address" value="<?php echo e($user->information->address); ?>">
                            </div>
                            <div class="input-box">
                                <span class="details">Sinh nhật</span>
                                <input type="date" value="<?php echo e($user->information->birthday); ?>" name="birthday">
                            </div>
                            <div class="input-box">
                                <span class="details">Sở thích</span>
                                <input type="text" value="<?php echo e($user->information->hobbies); ?>" name="hobbies">
                            </div>
                            <div class="input-box">
                                <span class="details">Ảnh đại diện</span>
                                <input type="file" name="avatar">
                                <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <textarea type="text" id="editor" name="description" value="<?php echo e(old('description')); ?>"></textarea>
                        </div>
                        <div>
                            <span class="detail"> Avatar trước đó: </span>
                            <img src="<?php echo e(asset('storage/avatar/' . $user->information->avatar)); ?>"
                                style="width:13%; margin: 1em 0">
                        </div>
                        <div class="gender-details">
                            <input type="radio" name="gender" value="male"
                                <?php echo e('male' == $user->information->gender ? 'checked' : ''); ?> id="dot-1">
                            <input type="radio" name="gender" value="female"
                                <?php echo e('female' == $user->information->gender ? 'checked' : ''); ?> id="dot-2">
                            <span class="gender-title">Gender</span>
                            <div class="category">
                                <label for="gender">Male</label>
                                <input style="display: block" type="radio" name="gender"
                                    <?php echo e('male' == $user->information->gender ? 'checked' : ''); ?> value="male">
                                <label for="gender">Female</label>
                                <input style="display: block" type="radio" name="gender"
                                    <?php echo e('female' == $user->information->gender ? 'checked' : ''); ?> value="female">
                            </div>
                        </div>
                        <div class="button">
                            <input type="submit" value="Submit">
                        </div>
                    </form>
                <?php else: ?>
                    <form action="<?php echo e(url('information/store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="user-details">
                            <input type="text" name="user_id" value="<?php echo e($user->id); ?>" hidden>
                            <div class="input-box">
                                <span class="details">Full Name</span>
                                <input type="text" placeholder="Điền họ tên đầy đủ" name="fullname">
                                <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="input-box">
                                <span class="details">Phone</span>
                                <input type="tel" name="phone" placeholder="Điền số điện thoại">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="input-box">
                                <span class="details">Địa chỉ</span>
                                <input type="text" name="address" placeholder="Điền địa chỉ">
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="input-box">
                                <span class="details">Sinh nhật</span>
                                <input type="date" placeholder="Enter your number" name="birthday">
                                <?php $__errorArgs = ['birthday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="input-box">
                                <span class="details">Sở thích</span>
                                <input type="text" placeholder="Điền sở thích" name="hobbies">
                                <?php $__errorArgs = ['hobbies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="input-box">
                                <span class="details">Ảnh đại diện</span>
                                <input type="file" name="avatar">
                                <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <textarea type="text" id="editor" name="description" placeholder="Mô tả về bản thân bạn"></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="gender-details">
                            <input type="radio" name="gender" value="male" id="dot-1">
                            <input type="radio" name="gender" value="female" id="dot-2">
                            <span class="gender-title">Gender</span>
                            <div class="category">
                                <label for="dot-1">
                                    <span class="dot one">Male</span>
                                    <input type="radio" name="gender" value="male">
                                </label>
                                <label for="dot-2">
                                    <span class="dot two">Female</span>
                                    <input type="radio" name="gender" value="female">
                                </label>
                            </div>
                        </div>
                        <div class="button">
                            <button type="submit" class="primary_button btn_information">Submit</button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        let myEditor;
        ClassicEditor
            .create(document.querySelector('#editor'))
            .catch(error => {
                console.error(error);
            });

        const dpt_menu = document.querySelectorAll('.dpt_menu');
        const close_menu = document.querySelectorAll('#close_menu');

        for (let i of dpt_menu) {
            i.classList.add('active');
        }
        close_menu.forEach((item) => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                for (let i of dpt_menu) {
                    i.classList.toggle('active');
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\ICT\resources\views/user/design/information/edit.blade.php ENDPATH**/ ?>