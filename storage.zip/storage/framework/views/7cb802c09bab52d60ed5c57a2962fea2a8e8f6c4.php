
<?php $__env->startSection('title'); ?>
    Danh sách yêu thích của bạn
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(Auth::check()): ?>
    <?php if($wishlists->count() > 0 ): ?> 
    <h1 class="search_page">Danh sách phim yêu thích của bạn</h1>
    <div class="features">
        <div class="container">
            <div class="wrapper">
                <div class="column">
                    <div class="products main flexwrap">
                        <?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item page_other">
                                <form action="<?php echo e(url('wishlist/delete/' .$result->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="remove_wishlist">
                                        <i class="ri-close-line"></i>
                                    </button>
                                </form>
                                <div class="media" style="position: relative">
                                   
                                    <div class="thumbnail object_cover">
                                        <?php if($result->product->sale == 0): ?>
                                        <a href="<?php echo e(url('detail/' . $result->product->id)); ?>">
                                            <img src="<?php echo e($result->product->images->first()->path); ?>" alt="<?php echo e($result->product->name); ?>">
                                        </a>
                                        <?php else: ?>
                                        <a href="<?php echo e(url('pageoffer/' . $result->product->id)); ?>">
                                            <img src="<?php echo e($result->product->images->first()->path); ?>" alt="<?php echo e($result->product->name); ?>">
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                    <div class="hoverable">
                                        <ul>
                                            <li class="active"><a href="" style="background: #ff6b6b;opacity:1;"><i class="ri-heart-line"></i></a></li>
                                            <?php if($result->product->sale == 0): ?>
                                            <li><a href="<?php echo e(url('detail/' . $result->product->id)); ?>"><i class="ri-eye-line"></i></a></li>
                                            <?php else: ?>
                                            <li><a href="<?php echo e(url('pageoffer/' . $result->product->id)); ?>"><i class="ri-eye-line"></i></a></li>
                                            <?php endif; ?>
                                            <li><a href=""><i class="ri-shuffle-line"></i></a></li>
                                        </ul>
                                    </div>
                                    <?php if($result->product->discount): ?>
                                        <div class="discount circle flexcenter"><span><?php echo e($result->product->discount); ?>%</span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="content">
                                    <div class="rating">
                                        <?php if(80 * ($result->product->reviews()->pluck('feedbacks.rate')->avg() / 5) == 0): ?>
                                        <div class="stars" style="background-image:none;width:150px">Chưa có đánh giá</div> 
                                        <?php else: ?>
                                        <div class="stars" style="width:<?php echo e(80 * ($result->product->reviews()->pluck('feedbacks.rate')->avg() / 5)); ?>px "></div> 
                                        <?php endif; ?>
                                        <div class="mini_text">(<?php echo e($result->product->reviews->count()); ?>) </div>
                                    </div>
                                    <?php if($result->product->sale == 0): ?>
                                    <h3 class="main_links"><a
                                            href="<?php echo e(url('detail/' . $result->product->id)); ?>"><?php echo e(Illuminate\Support\Str::of($result->product->name)->words(9)); ?></a>
                                    </h3>
                                    <?php else: ?>
                                    <h3 class="main_links"><a
                                        href="<?php echo e(url('pageoffer/' . $result->product->id)); ?>"><?php echo e(Illuminate\Support\Str::of($result->product->name)->words(9)); ?></a>
                                </h3>
                                    <?php endif; ?>
                                    <div class="price">
                                        <?php if($result->product->discount): ?>
                                            <span
                                                class="current"><?php echo e(number_format(floor($result->product->price - ($result->product->price * $result->product->discount) / 100))); ?>

                                                VND</span>
                                            <span class="normal mini_text"><?php echo e(number_format($result->product->price)); ?> VND</span>
                                        <?php else: ?>
                                            <span class="current"><?php echo e(number_format($result->product->price)); ?> VND</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="footer">
                                        <ul class="mini_text">
                                            <li>Cotton, Polyester</li>
                                            <li>100% nguyên chất</li>
                                            <li>Phong cách</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <h1 class="search_page">Bạn chưa có phim yêu thích nào</h1>
    <?php endif; ?>   
    <?php endif; ?>

    <?php echo e($wishlists->links('vendor.pagination.default')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>
    
    <script>
        const dpt_menu = document.querySelectorAll('.dpt_menu');
        const close_menu = document.querySelectorAll('#close_menu');
       
       for(let i of dpt_menu){
        i.classList.add('active');
       }
       close_menu.forEach((item)=>{
         item.addEventListener('click', (e) => {
            e.preventDefault();
            for(let i of dpt_menu){
                i.classList.toggle('active');
            }
       });
    })    

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp1\htdocs\Fashion\resources\views/user/design/wishlist.blade.php ENDPATH**/ ?>