
<?php $__env->startSection('title'); ?>
    Chi tiết sản phẩm <?php echo e(Illuminate\Support\Str::of($products->name)->words(4)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <ul class="notification">
    </ul>
    <div class="single_product">
        <div class="container">
            <div class="wrapper">

                

                <div class="breadcrumb">
                    <ul class="flexitem">
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li><?php echo e($products->name); ?></li>
                    </ul>
                </div>

                

                <div class="column">
                    <div class="products one">
                        <div class="flexwrap">
                            <div class="row">
                                <div class="item is_sticky">
                                    <?php if($products->discount): ?>
                                        <div class="price">
                                            <span class="discount"
                                                style="background-color: #bd7f7f"><?php echo e($products->discount); ?>%<br>Giảm</span>
                                        </div>
                                    <?php endif; ?>
                                    <div class="big_image">
                                        <div class="big_image_wrapper swiper-wrapper">
                                            <?php $__currentLoopData = $products->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="image_show swiper-slide">
                                                    <a data-fslightbox href="<?php echo e($image->path); ?>"><img
                                                            src="<?php echo e($image->path); ?>" alt="<?php echo e($products->name); ?>"></a>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="swiper-button-next"></div>
                                        <div class="swiper-button-prev"></div>
                                    </div>
                                    <div class="small_image">
                                        <ul class="small_image_wrapper flexitem swiper-wrapper">
                                            <?php $__currentLoopData = $products->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="thumbnail_show swiper-slide">
                                                    <img src="<?php echo e($image->path); ?>" alt="<?php echo e($products->name); ?>">"
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="item">
                                    <h1><?php echo e($products->name); ?></h1>
                                    <div class="content">
                                        <div class="rating">
                                            <?php if(80 *
                                            ($products->reviews()->pluck('feedbacks.rate')->avg() /
                                                5) ==
                                            0): ?>
                                        <div class="stars" style="background-image:none;width:150px">Chưa có
                                            đánh giá</div>
                                        <?php else: ?>
                                            <div class="stars"
                                                style="width:<?php echo e(80 *($products->reviews()->pluck('feedbacks.rate')->avg() /5)); ?>px ">
                                            </div>
                                        <?php endif; ?>
                                            <a href="" class="mini_text render_count"><?php echo e($products->reviews->count()); ?>

                                                review</a>
                                        </div>
                                    </div>
                                    <div class="stock_sku">
                                        <span class="avaiable">Số lượng</span>
                                        <span class="sku mini_text">160</span>
                                    </div>
                                    <div class="price">
                                        <?php if($products->discount): ?>
                                            <span
                                                class="current"><?php echo e(number_format(floor($products->price - ($products->price * $products->discount) / 100))); ?>

                                                VND</span>
                                            <span class="normal mini_text"><?php echo e(number_format($products->price)); ?>

                                                VND</span>
                                        <?php else: ?>
                                            <span class="current"><?php echo e(number_format($products->price)); ?> VND</span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="voucher">
                                        <?php if($products->vouchers->count() > 0): ?>
                                            <h4>Voucher của sản phẩm:
                                                <?php $__currentLoopData = $products->vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($voucher->value); ?>,
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </h4>
                                        <?php endif; ?>
                                    </div>

                                    <form action="<?php echo e(url('payment')); ?>" method="POST" id="form_cart">
                                        <?php echo csrf_field(); ?>
                                        <input name="product_id" hidden value="<?php echo e($products->id); ?>">
                                        <div class="color">
                                            <p>Color</p>
                                            <div class="variant">
                                                <?php $__currentLoopData = $products->attributevalues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($color->attribute_id == 2): ?>
                                                        <p>
                                                            <input type="radio" name="color" id="<?php echo e($color->value); ?>"
                                                                value="<?php echo e($color->id); ?>">
                                                            <label for="<?php echo e($color->value); ?>" class="circle size_bf"
                                                                style="top:0; left:0; --bg:<?php echo e($color->value); ?> "></label>
                                                        </p>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <div class="sizes">
                                            <p>Size</p>
                                            <div class="variant">
                                                <?php $__currentLoopData = $products->attributevalues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($size->attribute_id == 1): ?>
                                                        <P>
                                                            <input type="radio" name="size" id="<?php echo e($size->value); ?>"
                                                                value="<?php echo e($size->id); ?>">
                                                            <label for="<?php echo e($size->value); ?>" class="circle size_bf"
                                                                style="top:0; left:0;"><span><?php echo e($size->value); ?></span></label>
                                                        </P>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="actions">
                                            <div class="qty_control flexitem">
                                                <div class="minus circle">-</div>
                                                <input type="number" id="stock" value="1" name="stock"
                                                    min="1" max="<?php echo e($products->stock); ?>" required>
                                                <div class="plus circle">+</div>
                                            </div>
                                            <?php if($products->stock > 0): ?>
                                            <div class="button_cart">
                                                <button class="primary_button" id="addtocart"
                                                    onclick="addCart(<?php echo e($products->id); ?>)">Add to cart</button>
                                            </div>
                                            <div class="button_cart" style="margin-right: 1em">
                                                <button type="submit" class="secondary_button">Mua ngay</button>
                                            </div>
                                        <?php else: ?>
                                            <div class="button_cart">
                                                <button class="primary_button" id="addtocart" style="opacity: .5" onclick="soldOut(this)">Add to cart</button>
                                            </div>
                                            <div class="button_cart" style="margin-right: 1em">
                                                <button type="submit" class="secondary_button" style="opacity: .5" onclick="soldOut(this)">Mua ngay</button>
                                            </div>
                                        <?php endif; ?>
                                    </form>
                                </div>

                                <div class="wish_share">

                                    <ul class="flexitem second_links" id="wish_love">
                                        <?php if(Auth::check()): ?>
                                            <?php if(App\Models\Wishlist::where('user_id', Auth::user()->id)->where('product_id', $products->id)->count() > 0): ?>
                                            <?php $__currentLoopData = App\Models\Wishlist::where('user_id', Auth::user()->id)->where('product_id', $products->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $love): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="#" id="wishlist"
                                                    onclick="wishlistDelete(<?php echo e($love->id); ?>,<?php echo e($products->id); ?>,<?php echo e(Auth::user()->id); ?>)">
                                                    <span class="icon_large" style="color: #ff6b6b"><i
                                                            class="ri-heart-fill"></i></span>
                                                    <span id="love" style="color: #ff6b6b">Đã yêu thích</span>
                                                </a>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          <?php else: ?>
                                            <li>    
                                                <a href="#" id="wishlist"
                                                    onclick="wishlist(<?php echo e($products->id); ?>,<?php echo e(Auth::user()->id); ?>)">
                                                    <span class="icon_large"><i class="ri-heart-line"></i></span>
                                                    <span id="love">Yêu thích</span>
                                                </a>
                                            </li>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <li>
                                                <div id="wishlist" onclick="createToast('Bạn phải đăng nhập')"
                                                    style="cursor: pointer">
                                                    <span class="icon_large"><i class="ri-heart-line"></i></span>
                                                    <span id="love">Yêu thích</span>
                                                </div>
                                            </li>
                                        <?php endif; ?>
                                        <li>
                                            <a href="">
                                                <span class="icon_large"><i class="ri-share-line"></i></span>
                                                <span>Chia sẻ</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="descripition collapse">
                                <ul>
                                    <li class="has_child expand ">
                                        <a href="#" class="icon_small">Thông tin sản phẩm</a>
                                        <div class="content">
                                            <ul>
                                                <li><span>Brand:</span><a
                                                        href="<?php echo e(url('brand/'.$products->brand_id)); ?>"><span><?php echo e($products->brand->name); ?></span></a>
                                                </li>
                                                <li><span>Category:</span>
                                                    <?php $__currentLoopData = $products->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(url('category/'. $category->id)); ?>">
                                                            <span><?php echo e($category->name); ?>,</span></a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </li>
                                                <li><span>Số lượng: </span><span><?php echo e($products->stock); ?></span>
                                                </li>
                                                <li><span>Đã bán:</span><span><?php echo e($products->sold); ?> sản phẩm </span></li>
                                                <li><span>Đánh giá:</span><span><?php echo e(round($rate, 1)); ?> sao</span></li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li class="has_child">
                                        <a href="#0" class="icon_small">Giới thiệu sản phẩm</a>
                                        <div class="content">
                                            <p><?php echo $products->desce; ?></p>
                                        </div>
                                    </li>
                                    <li class="has_child">
                                        <a href="#0" class="icon_small">Bảng size </a>
                                        <div class="content">
                                            <div class="table">
                                                <table style="width:100%">
                                                    <thead>
                                                        <tr>
                                                            <th>Size</th>
                                                            <th><span class="mini_text">Rộng</span>(cm)</th>
                                                            <th><span class="mini_text">Eo</span>(cm)</th>
                                                            <th><span class="mini_text">Hông</span>(cm)</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>S</td>
                                                            <td>82.5</td>
                                                            <td>62.5</td>
                                                            <td>87.5</td>
                                                        </tr>
                                                        <tr>
                                                            <td>M</td>
                                                            <td>85</td>
                                                            <td>63.5</td>
                                                            <td>89</td>
                                                        </tr>
                                                        <tr>
                                                            <td>L</td>
                                                            <td>87.5</td>
                                                            <td>67.5</td>
                                                            <td>93</td>
                                                        </tr>
                                                        <tr>
                                                            <td>XL</td>
                                                            <td>90</td>
                                                            <td>72.5</td>
                                                            <td>98</td>
                                                        </tr>
                                                        <tr>
                                                            <td>XXL</td>
                                                            <td>93</td>
                                                            <td>77.5</td>
                                                            <td>103</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="has_child">
                                        <a href="#" class="icon_small">Đánh giá<span
                                                class="mini_text render_count"><?php echo e($products->reviews->count()); ?></span></a>
                                        <div class="content">
                                            <div class="reviews">
                                                <h4>Bình luận của mọi người</h4>
                                                <div class="review_block">
                                                    <div class="review_block_head">
                                                        <div class="flexitem">
                                                            <span class="rate_sum"><?php echo e(round($rate, 1)); ?>

                                                                sao</span>
                                                            <span class="render_count">Trên
                                                                <?php echo e($products->reviews->count()); ?> đánh
                                                                giá</span>
                                                        </div>
                                                        <?php if(Auth::check()): ?>
                                                            <a href="#review_form" class="secondary_button">Viết
                                                                bình luận</a>
                                                        <?php else: ?>
                                                            <a href="#" class="secondary_button"
                                                                id="review_btn">Viết bình luận
                                                        <?php endif; ?>
                                                        </a>
                                                        <div class="review_block_body">
                                                            <ul id="review_ul">

                                                                <?php $__currentLoopData = $products->reviews()->orderBy('created_at', 'desc')->limit(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li class="item">
                                                                        <div class="review_form">
                                                                            <p class="person">Bình luận bởi
                                                                                <?php echo e($review->name); ?>

                                                                            </p>
                                                                            <p class="mini_text">Vào ngày
                                                                                <?php echo e(date('d-m-Y'), strtotime($review->created_at)); ?>

                                                                            </p>
                                                                        </div>
                                                                        <div class="review_rating rating">
                                                                            <div class="stars"
                                                                                style="width: <?php echo e(80 * ($review->rate / 5)); ?>px">
                                                                            </div>
                                                                        </div>
                                                                        <div class="review_img object_cover">
                                                                            <?php if($review->image): ?>
                                                                                <img src="<?php echo e(asset('' . $review->image)); ?>"
                                                                                    style="position: static;width:200px;height:200px">
                                                                            <?php endif; ?>
                                                                        </div>
                                                                        <div class="review_title">
                                                                            <p><?php echo e($review->title); ?></p>
                                                                        </div>
                                                                        <div class="review_text">
                                                                            <p><?php echo e($review->content); ?></p>
                                                                        </div>
                                                                        <?php if(Auth::check()): ?>
                                                                            <?php if(Auth::user()->name === $review->name || Auth::user()->role_id == 2): ?>
                                                                                <div style="display:flex; gap:1em;">
                                                                                    <a href="#review_form"
                                                                                        class="primary_button"
                                                                                        style="border: none;outline:none"
                                                                                        id="btn_edit"
                                                                                        onclick="sendEdit(<?php echo e($review->id); ?>)">Sửa</a>
                                                                                    <button type="submit"
                                                                                        class="secondary_button"
                                                                                        id="btn_delete"
                                                                                        style="border:none; outline:none"
                                                                                        onclick="sendDelete(<?php echo e($review->id); ?>)">
                                                                                        Xóa </button>
                                                                                </div>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                    </li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                            <div class="second_links">
                                                                <a href="#" class="view_all">
                                                                    Xem tất cả bình luận
                                                                    <i class="ri-arrow-right-line"></i>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <?php if(Auth::check()): ?>
                                                            <div id="review_form" class="review_form">
                                                                <h4>Viết bình luận của bạn</h4>
                                                                <div class="form_review_user">
                                                                    <form class="user_review"
                                                                        action="<?php echo e(url('/review/store/' . $products->id)); ?>"
                                                                        method="POST" enctype="multipart/form-data">
                                                                        <?php echo csrf_field(); ?>
                                                                        <div class="rating">
                                                                            <p>Bạn có thấy hài lòng?</p>
                                                                            <div class="rate_this"
                                                                                style="margin-bottom: 23px">
                                                                                <input type="radio" name="rate"
                                                                                    id="star5" value="5">
                                                                                <label for="star5"><i
                                                                                        class="ri-star-fill"></i></label>
                                                                                <input type="radio" name="rate"
                                                                                    id="star4" value="4">
                                                                                <label for="star4"><i
                                                                                        class="ri-star-fill"></i></label>
                                                                                <input type="radio" name="rate"
                                                                                    id="star3" value="3">
                                                                                <label for="star3"><i
                                                                                        class="ri-star-fill"></i></label>
                                                                                <input type="radio" name="rate"
                                                                                    id="star2" value="2">
                                                                                <label for="star2"><i
                                                                                        class="ri-star-fill"></i></label>
                                                                                <input type="radio" name="rate"
                                                                                    id="star1" value="1">
                                                                                <label for="star1"><i
                                                                                        class="ri-star-fill"></i></label>
                                                                            </div>
                                                                        </div>
                                                                        <p>
                                                                            <label>Tiêu đề</label>
                                                                            <input type="text" name="title" required>
                                                                        </p>
                                                                        <p>
                                                                            <label>Ảnh review</label>
                                                                            <input type="file" name="image">
                                                                        </p>
                                                                        <p>
                                                                            <label>Bình luận</label>
                                                                            <textarea cols="30" rows="10" name="content" required></textarea>
                                                                        </p>
                                                                        <p>
                                                                            <input type="text" hidden name="name"
                                                                                value="<?php echo e(Auth::user()->name); ?>">
                                                                            <input type="text" hidden name="email"
                                                                                value="<?php echo e(Auth::user()->email); ?>">
                                                                        </p>
                                                                        <button id="button_review" type="submit"
                                                                            class="primary_button"
                                                                            style="border:none; outline:none">Bình
                                                                            luận</button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <div class="related_products">
        <div class="container">
            <div class="wrapper">
                <div class="column">
                    <div class="sectop flexitem">
                        <h2><span class="circle"></span><span>Sản phẩm liên quan</span></h2>
                        <div class="second_links"><a href="" class="view_all">Xem tất cả<i
                                    class="ri-arrow-right-line"></i></a></div>
                    </div>
                    <div class="products main flexwrap">
                        <?php $__currentLoopData = App\Models\admin\Product::where('sale', '=', 0)->where('brand_id', $products->brand_id)->where('id', '!=', $products->id)->inRandomOrder()->limit(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item page_other">
                                <div class="media">
                                    <div class="thumbnail object_cover">
                                        <a href="<?php echo e(url('detail/' . $product->id)); ?>">
                                            <img src="<?php echo e($product->images->first()->path); ?>" alt="<?php echo e($product->name); ?>">
                                        </a>
                                    </div>
                                    <div class="hoverable">
                                        <ul>
                                            <li class="active"><a href=""><i class="ri-heart-line"></i></a></li>
                                            <li><a href="<?php echo e(url('pageoffer/' . $product->id)); ?>"><i
                                                        class="ri-eye-line"></i></a></li>
                                            <li><a href=""><i class="ri-shuffle-line"></i></a></li>
                                        </ul>
                                    </div>
                                    <?php if($product->discount): ?>
                                        <div class="discount circle flexcenter">
                                            <span><?php echo e($product->discount); ?>%</span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="content">
                                    <div class="rating">
                                        <?php if(80 *
                                                ($product->reviews()->pluck('feedbacks.rate')->avg() /
                                                    5) ==
                                                0): ?>
                                            <div class="stars" style="background-image:none;width:150px">Chưa có đánh giá
                                            </div>
                                        <?php else: ?>
                                            <div class="stars"
                                                style="width:<?php echo e(80 *($product->reviews()->pluck('feedbacks.rate')->avg() /5)); ?>px ">
                                            </div>
                                        <?php endif; ?>
                                        <div class="mini_text"><?php echo e($product->reviews->count()); ?> review</div>
                                    </div>
                                    <h3 class="main_links"><a
                                            href="<?php echo e(url('detail/' . $product->id)); ?>"><?php echo e(Illuminate\Support\Str::of($product->name)->words(9)); ?></a>
                                    </h3>
                                    <div class="price">
                                        <?php if($product->discount): ?>
                                            <span
                                                class="current"><?php echo e(number_format(floor($product->price - ($product->price * $product->discount) / 100))); ?>

                                                VND</span>
                                            <span class="normal mini_text"><?php echo e(number_format($product->price)); ?>

                                                VND</span>
                                        <?php else: ?>
                                            <span class="current"><?php echo e(number_format($product->price)); ?>

                                                VND</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="footer">
                                        <ul class="mini_text">
                                            <li>Cotton, Polyester</li>
                                            <li>100% nguyên chất</li>
                                            <li>Phong cách</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <?php if(Auth::check()): ?>
        <script>
            // comment
            const btn_review = document.querySelector('#button_review');
            const form_review = document.querySelector('.user_review');
            btn_review.addEventListener('click', (e) => {
                e.preventDefault();
                let title = document.querySelector('input[name="title"]').value;
                let image = document.querySelector('input[name="image"]').files[0];
                let content = document.querySelector('textarea[name="content"]').value;
                let rate = document.querySelector('input[name="rate"]').value;
                let name = document.querySelector('input[name="name"]').value;
                let email = document.querySelector('input[name="email"]').value
                sendDataCreate(name, email, rate, title, image, content);
                message = "Đã thêm bình luận"
                createNoti(message);
            })

            // Create review

            async function sendDataCreate(name, email, rate, title, image, content) {
                let form = new FormData();
                let dataReview = {
                    'name': `${name}`,
                    'email': `${email}`,
                    'rate': rate,
                    'title': `${title}`,
                    'content': `${content}`,
                }
                form.append('name', `${name}`);
                form.append('email', `${email}`);
                form.append('rate', rate);
                form.append('title', `${title}`);
                form.append('content', `${content}`);
                form.append('image', image);
                const res = await fetch(`http://127.0.0.1:8000/review/store/<?php echo e($products->id); ?>`, {
                        method: "POST",
                        // headers: {
                        //     "Content-Type": "application/json",
                        //     "X-Requested-With": "XMLHttpRequest",
                        // },
                        body: form,
                    }).then((response) => response.json())
                    .then((data) => {
                        showData(data);
                    })
                    .catch((error) => {
                        alert(error.message);
                    });
            }

            // delete review

            let btn_delete = document.querySelector('#btn_delete');

            async function sendDelete(id) {
                const res = await fetch(`http://127.0.0.1:8000/review/destroy/${id}`, {
                        method: "DELETE",
                        headers: {
                            "Content-Type": "application/json",
                            "X-Requested-With": "XMLHttpRequest",
                        },
                    })
                    .then((response) => response.json())
                    .then((data) => {
                        showData(data);
                    })
                    .catch((error) => {
                        alert(error.message);
                    });

                message = "Đã xóa bình luận";
                createNoti(message);

                return false;
            }


            // Edit comment

            async function sendEdit(id) {
                const res = await fetch(`http://127.0.0.1:8000/review/edit/${id}`)
                    .then((response) => response.json())
                    .then((data) => {
                        createForm(data);
                    })
                    .catch((error) => {
                        alert(error.message);
                    });
            };

            function createForm(data) {
                console.log(data.result.content);
                let form_review_user = document.querySelector('.form_review_user');
                form_review.style.display = 'none';
                let new_form = `
                <form class="user_review" id="form_reset" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                      <div class="rating">
                      <p>Đánh giá sản phẩm: </p>
                        <div class="rate_this" style="margin-bottom: 23px">
                            <input type="radio" name="rate" ${ 5 == data.result.rate ? 'checked' : ''} id="star5" value="5">
                            <label for="star5"><i class="ri-star-fill"></i></label>
                            <input type="radio" name="rate" id="star4" ${ 4 == data.result.rate ? 'checked' : ''} value="4">
                            <label for="star4"><i class="ri-star-fill"></i></label>
                            <input type="radio" name="rate" id="star3" ${ 3 == data.result.rate ? 'checked' : ''} value="3">
                            <label for="star3"><i class="ri-star-fill"></i></label>
                            <input type="radio" name="rate" id="star2" ${ 2 == data.result.rate ? 'checked' : ''} value="2">
                            <label for="star2"><i class="ri-star-fill"></i></label>
                            <input type="radio" name="rate" id="star1" ${ 1 == data.result.rate ? 'checked' : ''}  value="1">
                            <label for="star1"><i class="ri-star-fill"></i></label>
                            </div>
                        </div>
                              <p>
                             <label>Tiêu đề</label>
                              <input type="text" name="title" required value="${data.result.title}">
                            </p>
                            ${
                            (()=>{
                                if(data.result.image){
                                    return `
                                       <p>
                                         Ảnh review trước đó: 
                                         <img src="<?php echo e(asset('${data.result.image}')); ?>" style="position: static;width:160px;height:220px">    
                                       </p>
                                                                            `
                                }else{
                                    return `
                `
                                }
                            })()
                            }
                            
                           <p>
                           <label>Ảnh review <small>(Nếu muốn đổi)</small>)</label>
                         <input type="file" name="image" value="${data.result.file}">
                         </p>
                        <p>
                        <label>Bình luận</label>
                        <input cols="30" rows="10" name="content" required value="${data.result.content}"></input>
                         </p>
                        <p>
                         <input type="text" hidden name="name" value="${data.result.name}">
                         <input type="text" hidden name="email" value="${data.result.email}">
                         </p>
                         <button id="button_review_update" onclick="handleData(${data.result.id},event)" class="primary_button"
                         style="border:none; outline:none">Bình luận</button>                                                                
                         </form>                          
                `;
                form_review_user.innerHTML = new_form;

            }

            function handleData(id, e) {
                let title = document.querySelector('input[name="title"]').value;
                let image = document.querySelector('input[name="image"]').files[0];
                let content = document.querySelector('input[name="content"]').value;
                let rateBtn = document.querySelectorAll('input[name="rate"]');
                let name = document.querySelector('input[name="name"]').value;
                let email = document.querySelector('input[name="email"]').value;
                console.log(rateBtn);
                for (let i of rateBtn) {
                    if (i.checked) {
                        var rate = i.value;
                        console.log(rate);
                    }
                }
                sendData(id, name, email, rate, title, image, content);

                e.preventDefault();
            };

            async function sendData(id, name, email, rate, title, image, content) {
                let form = new FormData();
                let dataReview = {
                    'name': `${name}`,
                    'email': `${email}`,
                    'rate': rate,
                    'title': `${title}`,
                    'content': `${content}`,
                }
                form.append('name', `${name}`);
                form.append('email', `${email}`);
                form.append('rate', rate);
                form.append('title', `${title}`);
                form.append('content', `${content}`);
                form.append('image', image);
                const res = await fetch(`http://127.0.0.1:8000/review/update/${id}`, {
                        method: "POST",
                        // headers: {
                        //     "Content-Type": "application/json",
                        //     "X-Requested-With": "XMLHttpRequest",
                        // },
                        body: form,
                    }).then((response) => response.json())
                    .then((data) => {
                        showData(data);
                        message = 'Đã update bình luận';
                        createNoti(message);
                    })
                    .catch((error) => {
                        alert(error.message);
                    });

                return false;
            }


            function showData(data) {

                let show = '';
                let review_ul = document.querySelector('#review_ul');

                let count_render = data.result.filter((item) => {
                    return item.product_id == <?php echo e($products->id); ?>

                });


                let sort = count_render.sort(function(a, b) {
                    return b.id - a.id;
                });
                sort.slice(0, 6).map((item) => {
                    console.log(item);
                    let width = 80 * (item.rate / 5);
                    let date = new Date(item.created_at);
                    let time = (date.getDate()) +
                        '-' + (date.getMonth()) +
                        '-' + date.getFullYear()
                    console.log(item);
                    show += `
                <li class="item">
                   <div class="review_form">
                     <p class="person">Bình luận bởi ${item.name} </p>
                     <p class="mini_text">Vào ngày ${time} </p>
                   </div>
                <div class="review_rating rating">
                 <div class="stars" style="width:${width}px">
                 </div>
                  </div>
                   ${
                    (()=>{
                        if(item.image){
                            return `
                                    <div class="review_img object_cover">
                                    <img src="<?php echo e(asset('${item.image}')); ?>" style="position: static;width:200px;height:200px">
                                 </div>
                                      `
                        }else{
                            return `
                    `
                        }
                    })()
                   }
                     <div class="review_title">
                     <p>${item.title}</p>
                     </div>
                     <div class="review_text">
                      <p>${item.content}</p>
                      </div>
                      ${
                        (()=>{
                            if(item.name == '<?php echo e(Auth::user()->name); ?>' || <?php echo e(Auth::user()->role_id); ?>==2){
                                return `
                                   <div style="display:flex; gap:1em;">
                                    <a href="#review_form" class="primary_button" style="border: none;outline:none" id="btn_edit" onclick="sendEdit(${item.id})">Sửa</a>
                                    <button type="submit" class="secondary_button" id="btn_delete" style="border:none; outline:none" onclick="sendDelete(${item.id})"> Xóa </button>
                                   </div>
                                    `;
                            }else{
                                return `
                                       `
                            }
                        })()
                      }
                 </li>
                `;
                });
                review_ul.innerHTML = show;
                let render_count = document.querySelectorAll('.render_count');
                for (let i of render_count) {
                    i.innerText = count_render.length + ' reviews';
                }
                // reset Form 

                form_review.reset();
            }
        </script>
    <?php endif; ?>

    <script>
        const addToCart = document.querySelector('#addtocart');

        addToCart.addEventListener('click', (e) => {
            e.preventDefault();
        })

        const dpt_menu = document.querySelectorAll('.dpt_menu');
        const close_menu = document.querySelectorAll('#close_menu');

        for (let i of dpt_menu) {
            i.classList.add('active');
        }
        close_menu.forEach((item) => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                for (let i of dpt_menu) {
                    i.classList.toggle('active');
                }
            });
        })

           // Check produtct stock

           function soldOut(element){
            createToast('Xin lỗi đã hết hàng');
            return false;
        }

        // slider images

        var productThumb = new Swiper('.small_image', {
            loop: true,
            spaceBetween: 10,
            slidesPerview: 3,
            freeMode: true,
            watchSlidesProgress: true,
            breakpoints: {
                481: {
                    spaceBetween: 32,
                }
            }
        });

        var productBig = new Swiper('.big_image', {
            loop: true,
            autoHeight: true,
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            thumbs: {
                swiper: productThumb,
            }
        });


        // Check stock
        let quantity = document.querySelector('#stock');
        let minus = document.querySelector('.minus');
        let plus = document.querySelector('.plus');

        minus.addEventListener('click', (e) => {
            let value = parseInt(quantity.value);
            if (value > 1) {
                value -= 1;
                quantity.value = value;
            }
        });

        plus.addEventListener('click', (e) => {
            let value = parseInt(quantity.value);
            if (value < <?php echo e($products->stock); ?>) {
                value += 1;
                quantity.value = value;
            }
        });

        quantity.addEventListener('change', (e) => {
            if (e.target.value > <?php echo e($products->stock); ?>) {
                e.target.value = <?php echo e($products->stock); ?>;
                quantity.value = <?php echo e($products->stock); ?>;
            }
        });
    </script>

    <?php if(!Auth::check()): ?>
        <script>
            review_btn.addEventListener('click', (e) => {
                e.preventDefault();
                createToast('Bạn cần phải đăng nhập'); 
            })
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\ICT\resources\views/user/design/detail.blade.php ENDPATH**/ ?>