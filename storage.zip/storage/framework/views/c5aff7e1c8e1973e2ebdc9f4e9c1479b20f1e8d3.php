
<?php $__env->startSection('header'); ?>

    <header class="head_index">
    <div class="head_flex">
        <div class="logo_index">
            <h2>FASHION</h2>
        </div>
    <nav class="navbar">
        <a href="">TRANG CHỦ</a>
        <a href="">HÀNG MỚI NHẬP</a>
        <a href="">WOMEN</a>
        <a href="">MEN</a>
        <a href="">KHÁM PHÁ</a>
    </nav>
       <div class="auth_form">
       </div>
       </div>
    </div>
    </header>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.desgin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\ICT\resources\views/user/desgin/header.blade.php ENDPATH**/ ?>