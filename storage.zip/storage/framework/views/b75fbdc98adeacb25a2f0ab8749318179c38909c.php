
<?php $__env->startSection('title'); ?>
    Thông tin <?php echo e($category->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="single_category">
        <div class="container">
            <div class="wrapper">
                <div class="column">
                    <div class="holder">
                        <div class="row sidebar">
                            <div class="filter">
                                <div class="filter_block ">
                                    <h4>Category</h4>
                                    <ul>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <input type="checkbox" name="brand[]" id="<?php echo e($brand->name); ?>" value="<?php echo e($brand->id); ?>">
                                                    <label for="<?php echo e($brand->name); ?>">
                                                        <span class="checked"></span>
                                                        <span><?php echo e($brand->name); ?></span>
                                                    </label>
                                                </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <div class="filter_block products">
                                    <h4>Color</h4>
                                    <ul class="bycolor variant flexitem">
                                        <?php $__currentLoopData = App\Models\admin\ValueAttribute::where('attribute_id', '=', '2')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <input type="radio" name="color" id="<?php echo e($color->value); ?>">
                                                <label for="<?php echo e($color->value); ?>" class="circle" style="background-color:<?php echo e($color->value); ?>;margin-right:0.3em;"></label>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                               
                            </div>
                        </div>
                        <div class="section">
                            <div class="row">
                                <div class="cat_head">
                                    <div class="breadcrumb">
                                        <ul class="flexitem">
                                            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                            <li><?php echo e($category->name); ?></li>
                                        </ul>
                                    </div>
                                    <div class="page_title">
                                        <h1><?php echo e($category->name); ?></h1>
                                    </div>
                                    <div class="cat_description">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quibusdam, vitae. Est ullam deleniti aliquam minus in. Quasi iure officiis quod dolor corporis modi, suscipit velit amet culpa. Deserunt, sint praesentium?</p>
                                    </div>
                                    <div class="cat_navigation flexitem">
                                        <div class="item_filter desktop_hide">
                                            <a href="" class="filter_trigger lable">
                                                <i class="ri-menu-2-line"></i>
                                                <span>Lọc</span>
                                            </a>
                                        </div>
                                        <div class="item_sortir">
                                            <div class="lable">
                                                <span class="mobile_hide">
                                                    Sắp xếp theo
                                                </span>
                                                <div class="desktop_hide">Sắp xếp theo</div>
                                                <i class="ri-arrow-down-s-line"></i>
                                            </div>
                                            <ul>
                                                <li onclick="defaultFilter(this,<?php echo e($category->id); ?>)" value="1">Default</li>
                                                <li onclick="productName(this,<?php echo e($category->id); ?>)" value="2">Tên sản phẩm</li>
                                                <li onclick="price(this,<?php echo e($category->id); ?>)" value="3">Price</li>
                                            </ul>
                                        </div>
                                    
                                    </div>
                                </div>
                            </div>
                            <div class="products main flexwrap" id="show_filter">
                                <?php $__currentLoopData = $paginate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item">
                                    <div class="media">
                                        <div class="thumbnail object_cover">
                                            <?php if($product->sale == 0): ?>
                                                <a href="<?php echo e(url('detail/' . $product->id)); ?>">
                                                    <img src="<?php echo e($product->images->first()->path); ?>"
                                                        alt="<?php echo e($product->name); ?>">
                                                </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(url('pageoffer/' . $product->id)); ?>">
                                                    <img src="<?php echo e($product->images->first()->path); ?>"
                                                        alt="<?php echo e($product->name); ?>">
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                        <div class="hoverable">
                                            <ul>
                                                <li class="active"><a href=""><i class="ri-heart-line"></i></a></li>
                                                <?php if($product->sale == 0): ?>
                                                    <li><a href="<?php echo e(url('detail/' . $product->id)); ?>"><i
                                                                class="ri-eye-line"></i></a></li>
                                                <?php else: ?>
                                                    <li><a href="<?php echo e(url('pageoffer/' . $product->id)); ?>"><i
                                                                class="ri-eye-line"></i></a></li>
                                                <?php endif; ?>
                                                <li><a href=""><i class="ri-shuffle-line"></i></a></li>
                                            </ul>
                                        </div>
                                        <?php if($product->discount): ?>
                                            <div class="discount circle flexcenter"><span><?php echo e($product->discount); ?>%</span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="content">
                                        <div class="rating">
                                            <?php if(80 *
                                                    ($product->reviews()->pluck('feedbacks.rate')->avg() /
                                                        5) ==
                                                    0): ?>
                                                <div class="stars" style="background-image:none;width:150px">Chưa có
                                                    đánh giá</div>
                                            <?php else: ?>
                                                <div class="stars"
                                                    style="width:<?php echo e(80 *($product->reviews()->pluck('feedbacks.rate')->avg() /5)); ?>px ">
                                                </div>
                                            <?php endif; ?>
                                            <div class="mini_text"><?php echo e($product->reviews->count()); ?> review</div>
                                        </div>
                                        <?php if($product->sale == 0): ?>
                                            <h3 class="main_links"><a
                                                    href="<?php echo e(url('detail/' . $product->id)); ?>"><?php echo e(Illuminate\Support\Str::of($product->name)->words(9)); ?>

                                                </a>
                                            </h3>
                                        <?php else: ?>
                                            <h3 class="main_links"><a
                                                    href="<?php echo e(url('pageoffer/' . $product->id)); ?>"><?php echo e(Illuminate\Support\Str::of($product->name)->words(9)); ?></a>
                                            </h3>
                                        <?php endif; ?>
                                        <div class="price">
                                            <?php if($product->discount): ?>
                                                <span
                                                    class="current"><?php echo e(number_format(floor($product->price - ($product->price * $product->discount) / 100))); ?>

                                                    VND</span>
                                                <span class="normal mini_text"><?php echo e(number_format($product->price)); ?>

                                                    VND</span>
                                            <?php else: ?>
                                                <span class="current"><?php echo e(number_format($product->price)); ?> VND</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="footer">
                                            <ul class="mini_text">
                                                <li>Cotton, Polyester</li>
                                                <li>100% nguyên chất</li>
                                                <li>Phong cách</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        const dpt_menu = document.querySelectorAll('.dpt_menu');
        const close_menu = document.querySelectorAll('#close_menu');
        const form = document.querySelectorAll("input[name='categories[]']");
        const checkedValues = [];
        form.forEach((checkbox)=>{
            checkbox.addEventListener('click',(e)=>{
                if(e.target.checked){
                    checkedValues.push(e.target.value);
                }else{
                    const index = checkedValues.indexOf(event.target.value);
                    if (index !== -1) {
                        checkedValues.splice(index, 1);
                    }
                }
            })
        });

        

        const FtoShow = '.filter';
        const Fpopup = document.querySelector(FtoShow);
        const Ftrigger = document.querySelector('.filter_trigger');
        Ftrigger.addEventListener('click',(e)=>{
            e.preventDefault();
            setTimeout(() => {
               if(!Fpopup.classList.contains('show')){
                Fpopup.classList.add('show');
               } 
            }, 250);
        })
        document.addEventListener('click', (e)=>{
            const isClosest = e.target.closest(FtoShow);
            if(!isClosest && Fpopup.classList.contains('show')){
                Fpopup.classList.remove('show');
            }
        })



        // filtering

        function price(elemnet,id){
            filtering(id, elemnet.value);
        }

        function defaultFilter(elemnet,id){
            filtering(id, elemnet.value);
        }
        function productName(elemnet,id){
            filtering(id, elemnet.value);
        }
       async function filtering(id, value){
            const res = await fetch(`http://127.0.0.1:8000/filteringCategory/${id}/${value}`)
                .then((response) => response.json())
                .then((data) => {
                    showFilter(data);
                })
                .catch((error) => {
                    console.error("Error:", error);
                });
        }



        function showFilter(data) {
            let filter = '';
            console.log(data);
            data.result.map((item) => {
                if (item.discount) {
                    var price = (item.price - (item.price * ((item.discount) / 100)));
                } else {
                    var price = item.price;
                };
                filter+= `
                      <div class="item">
                                    <div class="media">
                                        <div class="thumbnail object_cover">
                                            ${
                                                (()=>{
                                                    if (item.sale == 0){
                                                        return `
                                                        <a href="<?php echo e(url('detail/${item.id}')); ?>">
                                                            <img src="${item.images[0].path}"
                                                                alt="${item.name}">
                                                        </a>
                                                        `
                                                    }
                                                    else{
                                                        return `
                                                        <a href="<?php echo e(url('pageoffer/${item.id}')); ?>">
                                                            <img src="${item.images[0].path}"
                                                                alt="${item.name}">
                                                        </a>
                                                        `
                                                    }
                                                })()
                                        }
                                        </div>
                                        <div class="hoverable">
                                            <ul>
                                                <li class="active"><a href=""><i class="ri-heart-line"></i></a></li>

                                                ${
                                                    (()=>{
                                                        if(item.sale == 0){
                                                        return `
                                                             <li><a href="<?php echo e(url('detail/${item.id}')); ?>"><i
                                                                class="ri-eye-line"></i></a></li>
                                                                `
                                                        }else{
                                                            return `
                                                            <li><a href="<?php echo e(url('pageoffer/${item.id}')); ?>"><i
                                                                class="ri-eye-line"></i></a></li>
                                                            `
                                                        }
                                                    })()
                                                }
                                                <li><a href=""><i class="ri-shuffle-line"></i></a></li>
                                            </ul>
                                        </div>

                                                 ${
                                                    (()=>{
                                                        if(item.discount >0){
                                                        return `
                                                        <div class="discount circle flexcenter">
                                                            <span>${item.discount}%</span>
                                                        </div>
                                                                `
                                                        }else{
                                                            return `
                                                            `
                                                        }
                                                    })()
                                                }
                                    </div>
                                    <div class="content">
                                              <div class="rating">
                                                ${
                                                    (()=>{
                                                        if(item.rate == 0){
                                                        return `
                                                        <div class="stars" style="background-image:none;width:150px">Chưa có đánh giá</div>
                                                                `
                                                        }else{
                                                            return `
                                                            <div class="stars" style="width:80 *(${item.rate} /5)px ">
                                                             </div>
                                                            `
                                                        }
                                                    })()
                                                }
                                            <div class="mini_text">${item.count} review</div>
                                          </div>
                                              ${
                                                    (()=>{
                                                        if(item.sale == 0){
                                                        return `
                                                        <h3 class="main_links"><a href="<?php echo e(url('detail/${item.id}')); ?>">${(item.name).substring(0,30)}</a>
                                                     </h3>
                                                                `
                                                        }else{
                                                            return `
                                                            <h3 class="main_links"><a href="<?php echo e(url('pageoffer/${item.id}')); ?>">${(item.name).substring(0,30)}</a>
                                                            `
                                                        }
                                                    })()
                                                }
                                        <div class="price">
                                            ${
                                                    (()=>{
                                                        if(item.discount >0){
                                                        return `
                                                        <span  class="current">${price.toLocaleString('vi-VN')} VND</span>
                                                         <span class="normal mini_text">${(item.price).toLocaleString('vi-VN')} VND</span>
                                                          `
                                                        }else{
                                                            return `
                                                            <span class="current">${(item.price).toLocaleString('vi-VN')} VND</span>
                                                            `
                                                        }
                                                    })()
                                                }
                                        </div>
                                        <div class="footer">
                                            <ul class="mini_text">
                                                <li>Cotton, Polyester</li>
                                                <li>100% nguyên chất</li>
                                                <li>Phong cách</li>
                                            </ul>
                                        </div>
                                    </div>
                     </div>
                `
            });
            document.querySelector('#show_filter').innerHTML = filter;
        }

        for (let i of dpt_menu) {
            i.classList.add('active');
        }
        close_menu.forEach((item) => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                for (let i of dpt_menu) {
                    i.classList.toggle('active');
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp1\htdocs\Fashion\resources\views/user/design/category.blade.php ENDPATH**/ ?>