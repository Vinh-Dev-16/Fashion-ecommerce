
<?php $__env->startSection('title'); ?>
    Trang sửa Brand
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  

    <div class="col-md-12">
        <div class="product">
            <div class="card">
                <div class="card-header">
                    <h2 style="font-size:25px;text-align:center;margin:10px 0">SỬA BRAND</h2>
                </div>
                <div class="card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Form sửa</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form action="<?php echo e(url('admin/brand/update/' . $brand->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>

                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleName">Tên brand sản phẩm</label>
                                <input type="text" class="form-control" id="exampleInputName" value="<?php echo e($brand->name); ?>"
                                    name="name">
                            </div>
                            <div class="form-group">
                                <label for="exampleName">Logo brand</label>
                                <input type="text" class="form-control" id="exampleInputName"
                                    value="<?php echo e($brand->logo); ?>" name="logo" >
                            </div>
                            <!-- /.card-body -->
                            <div class="form-group">
                                <label for="exampleName">Chi tiết Brand</label>
                                <textarea type="text" class="form-control" id="editor" name="description"
                                    placeholder="Điền thông tin sản phẩm"></textarea>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcumb'); ?>
    <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard.index')); ?>">Home</a></li>
        <li class="breadcrumb-item "><a href="<?php echo e(route('admin.brand.index')); ?>">Brand</a></li>
        <li class="breadcrumb-item active">Edit Brand</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

    <script>
            ClassicEditor
            .create( document.querySelector( '#editor' ) )
            .catch( error => {
                console.error( error );
            } );
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp1\htdocs\Fashion\resources\views/admin/brand/edit.blade.php ENDPATH**/ ?>