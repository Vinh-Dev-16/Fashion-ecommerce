
<?php $__env->startSection('title'); ?>
    Trang restore
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    
    <div class="col-md-12">
        <div class="restore">
            <div class="card">
                <div class="card-header">
                    <h2 style="font-size:25px;text-align:center;margin:10px 0">TRANG THÔNG TIN RESTORE</h2>
                    <h3 class="card-title">
                        <a href="<?php echo e(route('admin.product.index')); ?>">Quay lại trang product</a>
                    </h3>
                    <div class="card-tools">
                        <div class="input-group input-group-sm" style="width: 150px;">
                            <input type="text" name="table_search" id="search" class="form-control float-right"
                                placeholder="Search">
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-default">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body table-responsive p-0">
                    <table class="table table-hover text-nowrap">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tên sản phẩm</th>
                                <th>Giá</th>
                                <th>Giảm giá</th>
                                <th>Tồn kho</th>
                                <th>CRUD</th>
                            </tr>
                        </thead>
                        <tbody class="infor_restore">
                            <tr>
                                <?php $__currentLoopData = $restores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($restore->id); ?></td>
                                    <td><?php echo e(Illuminate\Support\Str::of($restore->name)->words(4)); ?></td>
                                    <td><?php echo e(number_format($restore->price)); ?> VND</td>
                                    <td><?php echo e($restore->discount); ?>%</td>
                                    <td><?php echo e($restore->stock); ?></td>
                                    <td class="table_crud" style="display:flex;justify-content:space-between;width:110px">

                                        <a href="<?php echo e(url('admin/product/restore/' . $restore->id)); ?>" title="Restore"
                                            style="border: none;outline:none">
                                            <i class="fa-solid fa-rotate-left" style="color: black; font-size:22px;"></i></a>
                                        <form method="post" action="<?php echo e(url('admin/product/delete/' . $restore->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" title="Xóa restore"
                                                onclick=" return confirm ('Bạn có muốn xóa không?')"
                                                style="border: none;outline:none;padding:0 13px;background:transparent"><i
                                                    class="fa-solid fa-trash"
                                                    style="color: #f4f4f; font-size:22px;"></i></button>
                                        </form>
                                    </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tbody id="search_result"></tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
        <?php echo e($restores->links()); ?>

        <div class="item"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcumb'); ?>
    <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard.index')); ?>">Home</a></li>
        <li class="breadcrumb-item active">Restore restores</li>
    </ol>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\ICT\resources\views/admin/product/restore.blade.php ENDPATH**/ ?>