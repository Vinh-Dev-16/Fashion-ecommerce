
<?php $__env->startSection('content'); ?>
    <?php if(Session::has('thongbao')): ?>
        <div class='noti success_noti' style="top: 43px;right:8px">
            <h2> Thông báo thành công </h2>
            <p> Đã thêm relationship </p>
        </div>
    <?php endif; ?>
    <?php if(Session::has('sua')): ?>
        <div class='noti success_noti' style="top: 43px;right:8px">
            <h2> Thông báo thành công </h2>
            <p> Đã sửa relationship </p>
        </div>
    <?php endif; ?>
    <?php if(Session::has('xoa')): ?>
        <div class='noti success_noti' style="top: 43px;right:8px">
            <h2> Thông báo thành công </h2>
            <p> Đã xóa relationship </p>
        </div>
    <?php endif; ?>
    

    <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-info">
            <div class="inner">
                <h3>150</h3>

                <p>New Orders</p>
            </div>
            <div class="icon">
                <i class="fa-solid fa-bag-shopping"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-success">
            <div class="inner">
                <h3>53<sup style="font-size: 20px">%</sup></h3>

                <p>Bounce Rate</p>
            </div>
            <div class="icon">
                <i class="fa-regular fa-percent"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-warning">
            <div class="inner">
                <h3>44</h3>

                <p>User Registrations</p>
            </div>
            <div class="icon">
                <i class="fa-solid fa-chart-pie"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-danger">
            <div class="inner">
                <h3>65</h3>

                <p>Unique Visitors</p>
            </div>
            <div class="icon">
                <i class="fa-brands fa-product-hunt"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>

    
    <div class="col-md-12" style="display:flex;align-items: center;justify-content:center">
        <div class="card product col-md-8">
            <div class="card">
                <div class="card-header">
                    <h2 style="font-size:25px;text-align:center;margin:10px 0">TRANG THÔNG TIN RELAYTONSHIP CATEGORY VS
                        PRODUCT</h2>
                    <h3 class="card-title"><a href="<?php echo e(route('admin.catpro.create')); ?>">Tạo mới relationship</a></h3>

                    <div class="card-tools">
                        <div class="input-group input-group-sm" style="width: 150px;">
                            <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                            <div class="input-group-append">
                                <button type="submit" class="btn btn-default">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body table-responsive p-0">
                    <table class="table table-hover text-nowrap">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tên loại sản phẩm</th>
                                <th>Số sản phẩm</th>
                                <th>CRUD</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <?php $__currentLoopData = $catpro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relationship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($relationship->id); ?></td>
                                    <?php $__currentLoopData = $relationship->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e(Illuminate\Support\Str::of($category->name)->words(6)); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($relationship->products->count() > 0): ?>
                                 
                                        <td><?php echo e(($relationship->products->count())); ?></td>
                                     <?php else: ?>
                                        <td>Chưa có sản phẩm</td>
                                    <?php endif; ?>
                                    <td class="table_crud" style="display:flex;justify-content:flex-start;">

                                        <a href="<?php echo e(url('admin/catpro/edit/' . $relationship->id)); ?>"
                                            title="Sửa Relationship" style="border: none;outline:none">
                                            <i class="fa-solid fa-pen" style="color: green; font-size:25px;"></i></a>
                                        <form method="post"
                                            action="<?php echo e(url('admin/catpro/destroy/' . $relationship->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" title="Xóa Relationship"
                                                onclick=" return confirm ('Bạn có muốn xóa không?')"
                                                style="border: none;outline:none;padding:0 13px;background:transparent"><i
                                                    class="fa-solid fa-trash"
                                                    style="color: red; font-size:25px;"></i></button>
                                        </form>
                                    </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
        <?php echo e($catpro->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcumb'); ?>
    <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item active">Relationship</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\ICT\resources\views/admin/catpro/index.blade.php ENDPATH**/ ?>