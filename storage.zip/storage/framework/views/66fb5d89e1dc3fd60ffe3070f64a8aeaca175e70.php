
<?php $__env->startSection('title'); ?>
    Trang checkout của <?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="single_checkout">
        <div class="container">
            <div class="wrapper">
                <div class="breadcrumb">
                    <ul class="flexitem">
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li>Thanh toán</li>
                    </ul>
                </div>
                <div class="checkout flexwrap">
                    <div class="item left styled">
                        <h1>Thông tin khách hàng</h1>
                        <?php $cartCollect = collect($cart);
                        $subTotal = $cartCollect->sum(function ($cartItem) {
                            if (!$cartItem['product']->discount) {
                                return $cartItem['quantity'] * $cartItem['product']->price;
                            } else {
                                return $cartItem['quantity'] * ($cartItem['product']->price - ($cartItem['product']->discount / 100) * $cartItem['product']->price);
                            }
                        });
                        ?>
                        <?php if(App\Models\Information::where('user_id', Auth::user()->id)->first()): ?>
                            <form action="<?php echo e(url('/process')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php $__currentLoopData = App\Models\Information::where('user_id', Auth::user()->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $information): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p>
                                        <label for="fullname">Full Name<span></span></label>
                                        <input type="text" name="fullname" value="<?php echo e($information->fullname); ?>">
                                    </p>
                                    <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <p>
                                        <label for="phone">Phone<span></span></label>
                                        <input type="phone" name="phone" value="<?php echo e($information->phone); ?>">
                                    </p>
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <p>
                                        <label for="address">Address<span></span></label>
                                        <input type="text" name="address" value="<?php echo e($information->address); ?>">
                                    </p>
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <p>
                                    <label for="note">Note<span></span></label>
                                    <input type="text" name="note" id="note">
                                </p>
                                <input type="text" name="user_id" value="<?php echo e(Auth::user()->id); ?>" hidden>
                                <input type="text" name="subtotal" value="<?php echo e($subTotal); ?>" hidden>
                                <p>
                                <div class="primary_checkout"><button class="primary_button"
                                        type="s
                                    ">Thanh toán</button></div>
                                </p>
                            </form>
                        <?php else: ?>
                            <form action="<?php echo e(url('/process')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <p>
                                    <label for="fullname">Full Name<span></span></label>
                                    <input type="text" name="fullname">
                                </p>
                                <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <p>
                                    <label for="phone">Phone<span></span></label>
                                    <input type="phone" name="phone">
                                </p>
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <p>
                                    <label for="address">Address<span></span></label>
                                    <input type="text" name="address">
                                </p>
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <p>
                                    <label for="note">Note<span></span></label>
                                    <input type="text" name="note" id="note">
                                </p>
                                <input type="text" name="user_id" value="<?php echo e(Auth::user()->id); ?>" hidden>
                                <input type="text" name="subtotal" value="<?php echo e($subTotal); ?>" hidden>
                                <p>
                                <div class="primary_checkout">
                                    <button class="primary_button" type="submit">Thanh toán</button></div>
                                </p>
                            </form>
                        <?php endif; ?>
                    </div>
                    <div class="item right">
                        <h2>Thông tin đơn hàng</h2>
                        <div class="sumary_order ">
                            <div class="sumary_totals">
                                <ul>
                                    <li>
                                        <span>Tổng tiền</span>
                                        <span><?php echo e(number_format($subTotal)); ?> VND</span>
                                    </li>
                                    <li>
                                        <span>Phí ship</span>
                                        <span><?php echo e(number_format(15000 * count($cart))); ?> VND</span>
                                    </li>
                                    <li>
                                        <span>Tax</span>
                                        <span><?php echo e(number_format($subTotal * 0.1)); ?> VND</span>
                                    </li>
                                    <li>
                                        <span>Tổng tất cả</span>
                                        <span><?php echo e(number_format($subTotal + 15000 * count($cart) + $subTotal * 0.1)); ?>

                                            VND</span>
                                    </li>
                                </ul>
                            </div>
                            <ul class="products mini">
                                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="item">
                                        <div class="thumbnail object_cover">
                                            <img src="<?php echo e($cart_product['image']); ?>"
                                                alt="<?php echo e($cart_product['product']->name); ?>">
                                        </div>
                                        <div class="item_content">
                                            <p><?php echo e($cart_product['product']->name); ?></p>
                                            <span class="price">
                                                <?php if($cart_product['product']->discount): ?>
                                                    <span><?php echo e(number_format($cart_product['quantity'] * ($cart_product['product']->price - ($cart_product['product']->discount / 100) * $cart_product['product']->price))); ?>

                                                        VND
                                                    </span>
                                                <?php else: ?>
                                                    <span><?php echo e(number_format($cart_product['quantity'] * $cart_product['product']->price)); ?></span>
                                                    VND
                                                <?php endif; ?>
                                            </span>
                                            <span>x<?php echo e($cart_product['quantity']); ?></span>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        const dpt_menu = document.querySelectorAll('.dpt_menu');
        const close_menu = document.querySelectorAll('#close_menu');

        for (let i of dpt_menu) {
            i.classList.add('active');
        }
        close_menu.forEach((item) => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                for (let i of dpt_menu) {
                    i.classList.toggle('active');
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp1\htdocs\Fashion\resources\views/user/design/checkout.blade.php ENDPATH**/ ?>