
<?php $__env->startSection('title'); ?>
    Đăng kí làm shipper
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if(App\Models\Information::where('user_id', Auth::user()->id)->count() > 0): ?>
    <div class="single_checkout">
      <div class="container">
          <div class="wrapper">
              <div class="breadcrumb">
                  <ul class="flexitem">
                      <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                      <li>Đăng kí làm shipper</li>
                  </ul>
              </div>
              <div class="checkout">
                  <div class="left styled" style="padding:4em 0">
                      <h1 style="text-align:center">Thông tin đăng kí</h1>
                      <form action="<?php echo e(url('/shipperSuccess')); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <?php $__currentLoopData = App\Models\Information::where('user_id', Auth::user()->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $information): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <p style="width:60%; margin-left:20%">
                              <label for="fullname">Full Name<span></span></label>
                              <input type="text" name="fullname" value="<?php echo e($information->fullname); ?>" >
                          </p>
                          <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="text-danger"><?php echo e($message); ?></div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          <p style="width:60%; margin-left:20%">
                              <label for="phone">Phone<span></span></label>
                              <input type="phone" name="phone" value="<?php echo e($information->phone); ?>">
                          </p>
                          <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="text-danger"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          <p style="width:60%; margin-left:20%">
                              <label for="address">Address<span></span></label>
                              <input type="text" name="address" value="<?php echo e($information->address); ?>">
                          </p style="width:60%; margin-left:20%">
                          <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="text-danger"><?php echo e($message); ?></div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <input type="text" name="user_id" value="<?php echo e(Auth::user()->id); ?>" hidden>
                          <p style="width:60%; margin-left:20%">
                              <div class="primary_checkout"><button class="primary_button" type="s
                                  ">Đăng kí làm Shipper</button></div>
                          </p>
                      </form>
                  </div>
              </div>
          </div>
      </div>
    </div>
    <?php else: ?>
      <div class="page_single">
          <div class="container" >
              <div class="wrapper">
                  <div class="breadcrumb">
                      <ul class="flexitem">
                          <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                          <li>Trang thông tin</li>
                      </ul>
                  </div>
              </div>
          </div>
      </div>
      <div class="form_information">
          <div class="container_information">
          <div class="title">Trang thông tin</div>
          <div class="content">
            <form action="<?php echo e(url('shipper/store')); ?>" method="POST" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="user-details">
                <input type="text" name="user_id" value="<?php echo e(Auth::user()->id); ?>" hidden>
                <div class="input-box">
                  <span class="details">Full Name</span>
                  <input type="text" placeholder="Điền họ tên đầy đủ" name="fullname" >
                  <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="input-box">
                  <span class="details">Phone</span>
                  <input type="tel" name="phone" placeholder="Điền số điện thoại">
                  <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="input-box">
                  <span class="details">Địa chỉ</span>
                  <input type="text" name="address" placeholder="Điền địa chỉ">
                  <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="input-box">
                  <span class="details">Sinh nhật</span>
                  <input type="date" placeholder="Enter your number" name="birthday">
                  <?php $__errorArgs = ['birthday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="input-box">
                  <span class="details">Sở thích</span>
                  <input type="text" placeholder="Điền sở thích" name="hobbies">
                  <?php $__errorArgs = ['hobbies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="input-box">
                  <span class="details">Ảnh đại diện</span>
                  <input type="file" name="avatar">
                  <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                  <textarea type="text" id="editor" name="description" placeholder="Mô tả về bản thân bạn"></textarea>
                  <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="gender-details">
                <input type="radio" name="gender" value="male" id="dot-1">
                <input type="radio" name="gender" value="female" id="dot-2">
                <span class="gender-title">Gender</span>
                <div class="category">
                  <label for="dot-1">
                  <span class="dot one">Male</span>
                  <input type="radio" name="gender" value="male">
                </label>
                <label for="dot-2">
                  <span class="dot two">Female</span>
                  <input type="radio" name="gender" value="female">
                </label>
                </div>
              </div>
              <div class="button">
                <button type="submit" class="primary_button btn_information" >Submit</button>
              </div>
            </form>   
          </div>
        </div>
      </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        const dpt_menu = document.querySelector('.dpt_menu');
        const close_menu = document.getElementById('close_menu');

        dpt_menu.classList.add('active');

        close_menu.addEventListener('click', (e) => {
            e.preventDefault();
            dpt_menu.classList.toggle('active');
        })

        let myEditor;
        ClassicEditor
        .create( document.querySelector( '#editor' ) )
        .catch( error => {
            console.error( error );
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\ICT\resources\views/user/design/shipper.blade.php ENDPATH**/ ?>