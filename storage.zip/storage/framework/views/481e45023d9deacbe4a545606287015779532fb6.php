
<?php $__env->startSection('title'); ?>
  Fashion 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    

    <div class="flex home_user  " style="background-image: url(<?php echo e(asset('images/bg1.jpg')); ?>);  filter: brightness(0.9);">
        <div class="text_slider">
        </div>
        <div class="slider_animation">
            <img src="<?php echo e(asset('images/ani1.png')); ?>" alt="slider1" class="ani1">
            <div class="img_slider slider1" style="background-image: url('<?php echo e(asset('images/slider1.png')); ?>')"></div>
            <img src="<?php echo e(asset('images/ani2.png')); ?>" alt="slider2" class="ani2">
            <div class="img_slider slider2" style="background-image: url('<?php echo e(asset('images/slider2.png')); ?>')"></div>
            <img src="<?php echo e(asset('images/ani3.png')); ?>" alt="slider3" class="ani3">
            <div class="img_slider slider3" style="background-image: url('<?php echo e(asset('images/slider3.png')); ?>')"></div>
        </div>
    </div>
    

    <div class="brand_home">
        <h3> Brand Fashion </h3>
        <div class="brand">
            <div class="container">
                <div class="wrapper flexitem">
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <a href="<?php echo e(url('brand/' . $brand->id)); ?>">
                                <img src="<?php echo e($brand->logo); ?>" alt="<?php echo e($brand->name); ?>">
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    

    <div class="trending">
        <div class="container">
            <div class="wrapper">
                <div class="sectop flexitem">
                    <h2><span class="circle"></span><span>Trending Products</span></h2>
                </div>
                <div class="column">
                    <div class="flexwrap">
                        <?php $__currentLoopData = App\Models\admin\Product::where('sale', '=', 1)->limit(1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row products big">
                                <div class="item">
                                    <div class="offer">
                                        <p>Offer hết hạn vào </p>
                                        <ul class="flexcenter">
                                            <li class="days"></li>
                                            <li class="hours"></li>
                                            <li class="minutes"></li>
                                            <li class="seconds"></li>
                                        </ul>
                                    </div>
                                    <div class="media">
                                        <div class="images">
                                            <a href="<?php echo e(url('pageoffer/' . $product->id)); ?>">
                                                <img src="<?php echo e($product->images->first()->path); ?>"
                                                    alt="<?php echo e($product->name); ?>">
                                            </a>
                                        </div>
                                        <div class="hoverable">
                                            <ul>
                                                <li class="active"><a href=""><i class="ri-heart-line"></i></a></li>
                                                <li><a href="<?php echo e(url('pageoffer/' . $product->id)); ?>"><i class="ri-eye-line"></i></a></li>
                                                <li><a href=""><i class="ri-shuffle-line"></i></a></li>
                                            </ul>
                                        </div>
                                        <div class="discount circle flexcenter"><span><?php echo e($product->discount); ?>%</span>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <div class="rating">
                                            <?php if(80 *
                                                    ($product->reviews()->pluck('feedbacks.rate')->avg() /
                                                        5) ==
                                                    0): ?>
                                                <div class="stars" style="background-image:none;width:150px">Chưa có
                                                    đánh giá</div>
                                            <?php else: ?>
                                                <div class="stars"
                                                    style="width:<?php echo e(80 *($product->reviews()->pluck('feedbacks.rate')->avg() /5)); ?>px ">
                                                </div>
                                            <?php endif; ?>
                                            <div class="mini_text"><?php echo e($product->reviews->count()); ?> review</div>
                                        </div>
                                        <h3 class="main_links"><a
                                                href="<?php echo e(url('detail/' . $product->id)); ?>"><?php echo e(Illuminate\Support\Str::of($product->name)->words(9)); ?></a>
                                        </h3>
                                        <div class="price">
                                            <span
                                                class="current"><?php echo e(number_format(floor($product->price - ($product->price * $product->discount) / 100))); ?>

                                                VND</span>
                                            <span class="normal mini_text"><?php echo e(number_format($product->price)); ?> VND</span>
                                        </div>
                                        <div class="stock mini_text">
                                            <div class="qty">
                                                <span>Số lượng: <strong
                                                        class="qty_available"><?php echo e($product->stock + $product->sold); ?></strong></span>
                                                <span>Đã bán: <strong class="qty_sold"><?php echo e($product->sold); ?></strong></span>
                                            </div>
                                            <div class="bar">
                                                <div class="available"></div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="row products mini">
                            <?php $__currentLoopData = App\Models\admin\Product::where('sale' , '=' ,1)->inRandomOrder()->limit(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="media">
                                    <div class="thumbnail " style="object-fit: cover">
                                        <a href="<?php echo e(url('pageoffer/' . $product->id)); ?>">
                                            <img src="<?php echo e($product->images->first()->path); ?>" style="height: 100%">
                                        </a>
                                    </div>
                                    <div class="hoverable">
                                        <ul>
                                            <li class="active"><a href=""><i class="ri-heart-line"></i></a></li>
                                            <li><a href="<?php echo e(url('detail/' . $product->id)); ?>"><i class="ri-eye-line"></i></a></li>
                                            <li><a href=""><i class="ri-shuffle-line"></i></a></li>
                                        </ul>
                                    </div>
                                    <?php if($product->discount): ?>
                                        <div class="discount circle flexcenter"><span><?php echo e($product->discount); ?>%</span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="content">
                                    <h3 class="main_links"><a
                                            href="<?php echo e(url('detail/' . $product->id)); ?>"><?php echo e(Illuminate\Support\Str::of($product->name)->words(4)); ?></a>
                                    </h3>
                                    <div class="rating">
                                        <?php if(80 * ($product->reviews()->pluck('feedbacks.rate')->avg() / 5) == 0): ?>
                                        <div class="stars" style="background-image:none;width:150px">Chưa có đánh giá</div> 
                                        <?php else: ?>
                                        <div class="stars" style="width:<?php echo e(80 * ($product->reviews()->pluck('feedbacks.rate')->avg() / 5)); ?>px "></div> 
                                        <?php endif; ?>
                                        <div class="mini_text"><?php echo e($product->reviews->count()); ?> review</div>
                                    </div>
                                    <div class="price">
                                        <?php if($product->discount): ?>
                                            <span
                                                class="current"><?php echo e(number_format(floor($product->price - ($product->price * $product->discount) / 100))); ?>

                                                VND</span>
                                            <span class="normal mini_text"><?php echo e(number_format($product->price)); ?> VND</span>
                                        <?php else: ?>
                                            <span class="current"><?php echo e(number_format($product->price)); ?> VND</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="mini_text">
                                        <p>Đã bán <?php echo e($product->sold); ?></p>
                                        <p>Free Shipping</p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="row products mini">
                            <?php $__currentLoopData = App\Models\admin\Product::where('sale' , '=' ,1)->inRandomOrder()->limit(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="media">
                                    <div class="thumbnail " style="object-fit: cover">
                                        <a href="<?php echo e(url('pageoffer/' . $product->id)); ?>">
                                            <img src="<?php echo e($product->images->first()->path); ?>" style="height: 100%">
                                        </a>
                                    </div>
                                    <div class="hoverable">
                                        <ul>
                                            <li class="active"><a href=""><i class="ri-heart-line"></i></a></li>
                                            <li><a href="<?php echo e(url('detail/' . $product->id)); ?>"><i class="ri-eye-line"></i></a></li>
                                            <li><a href=""><i class="ri-shuffle-line"></i></a></li>
                                        </ul>
                                    </div>
                                    <?php if($product->discount): ?>
                                        <div class="discount circle flexcenter"><span><?php echo e($product->discount); ?>%</span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="content">
                                    <h3 class="main_links"><a
                                            href="<?php echo e(url('detail/' . $product->id)); ?>"><?php echo e(Illuminate\Support\Str::of($product->name)->words(4)); ?></a>
                                    </h3>
                                    <div class="rating">
                                        <?php if(80 * ($product->reviews()->pluck('feedbacks.rate')->avg() / 5) == 0): ?>
                                        <div class="stars" style="background-image:none;width:150px">Chưa có đánh giá</div> 
                                        <?php else: ?>
                                        <div class="stars" style="width:<?php echo e(80 * ($product->reviews()->pluck('feedbacks.rate')->avg() / 5)); ?>px "></div> 
                                        <?php endif; ?>
                                        <div class="mini_text"><?php echo e($product->reviews->count()); ?> review</div>
                                    </div>
                                    <div class="price">
                                        <?php if($product->discount): ?>
                                            <span
                                                class="current"><?php echo e(number_format(floor($product->price - ($product->price * $product->discount) / 100))); ?>

                                                VND</span>
                                            <span class="normal mini_text"><?php echo e(number_format($product->price)); ?> VND</span>
                                        <?php else: ?>
                                            <span class="current"><?php echo e(number_format($product->price)); ?> VND</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="mini_text">
                                        <p>Đã bán <?php echo e($product->sold); ?></p>
                                        <p>Free Shipping</p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>
            </div>
        </div>
    </div>
    </div>


    

    <div class="features">
        <div class="container">
            <div class="wrapper">
                <div class="column">
                    <div class="sectop flexitem">
                        <h2><span class="circle"></span><span>View Products</span></h2>
                        <div class="second_links"><a href="<?php echo e(url('viewAllProducts')); ?>" class="view_all">Xem tất cả<i
                                    class="ri-arrow-right-line"></i></a></div>
                    </div>
                    <div class="products main flexwrap">
                        <?php $__currentLoopData = App\Models\admin\Product::where('sale' , '=' , 0)->inRandomOrder()->limit(9)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item page_other">
                                <div class="media">
                                    <div class="thumbnail object_cover">
                                        <a href="<?php echo e(url('detail/' . $product->id)); ?>">
                                            <img src="<?php echo e($product->images->first()->path); ?>" alt="<?php echo e($product->name); ?>">
                                        </a>
                                    </div>
                                    <div class="hoverable">
                                        <ul>
                                            <li class="active"><a href=""><i class="ri-heart-line"></i></a></li>
                                            <li><a href="<?php echo e(url('detail/' . $product->id)); ?>"><i class="ri-eye-line"></i></a></li>
                                            <li><a href=""><i class="ri-shuffle-line"></i></a></li>
                                        </ul>
                                    </div>
                                    <?php if($product->discount): ?>
                                        <div class="discount circle flexcenter"><span><?php echo e($product->discount); ?>%</span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="content">
                                    <div class="rating">
                                        <?php if(80 * ($product->reviews()->pluck('feedbacks.rate')->avg() / 5) == 0): ?>
                                        <div class="stars" style="background-image:none;width:150px">Chưa có đánh giá</div> 
                                        <?php else: ?>
                                        <div class="stars" style="width:<?php echo e(80 * ($product->reviews()->pluck('feedbacks.rate')->avg() / 5)); ?>px "></div> 
                                        <?php endif; ?>
                                        <div class="mini_text"><?php echo e($product->reviews->count()); ?> review</div>
                                    </div>
                                    <h3 class="main_links"><a
                                            href="<?php echo e(url('detail/' . $product->id)); ?>"><?php echo e(Illuminate\Support\Str::of($product->name)->words(9)); ?></a>
                                    </h3>
                                    <div class="price">
                                        <?php if($product->discount): ?>
                                            <span
                                                class="current"><?php echo e(number_format(floor($product->price - ($product->price * $product->discount) / 100))); ?>

                                                VND</span>
                                            <span class="normal mini_text"><?php echo e(number_format($product->price)); ?> VND</span>
                                        <?php else: ?>
                                            <span class="current"><?php echo e(number_format($product->price)); ?> VND</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="footer">
                                        <ul class="mini_text">
                                            <li>Cotton, Polyester</li>
                                            <li>100% nguyên chất</li>
                                            <li>Phong cách</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <div id="modal" class="modal">
        <div class="content flexcol">
            <div class="image object_cover">
                <img src="<?php echo e(asset('images/apparel4.jpg')); ?>">
            </div>
            <h2>Chào mừng đến với Fashion</h2>
            <p class="mobile_hide">Web Fashion E-commerce
                <br>
                Nhanh tay nhanh tay! Nhận ngay deal hot
            </p>
            <form action="" class="search">
                <span class="icon-large"><i class="ri-mail-line"></i></span>
                <input type="email" name="email" placeholder="Email của bạn" style="width:85%;padding: 0 2em 0 4.5em;">
                <button>Đăng kí</button>
            </form>
            <a href="" class="mini_text again">Không show nó lần nữa</a>
            <a href="#" class="t_close modalclose flexcenter">
                <i class="ri-close-line"></i>
            </a>
        </div>
    </div>
    <div class="overlay"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        if(window.sessionStorage.getItem('close')){
            window.onload = function(){
            document.querySelector('.site').classList.remove('showmodal')    
            }; 
        }else{
            window.onload  = function (){
            document.querySelector('.site').classList.toggle('showmodal')
        };
        }
        document.querySelector('.modalclose').addEventListener('click', function(){
            document.querySelector('.site').classList.remove('showmodal')
        });


        document.querySelector('.again').addEventListener('click', function(e){
            e.preventDefault();
            window.sessionStorage.setItem('close','showmodal');
            document.querySelector('.site').classList.remove('showmodal');
        });
        //Phần deal of day
        let countDate = new Date('29,Jun,2023 00:00:00').getTime();

        function countDown() {
            let now = new Date().getTime();

            gap = countDate - now;

            let seconds = 1000;
            let minutes = seconds * 60;
            let hours = minutes * 60;
            let day = hours * 24;
            let d = Math.floor(gap / (day)) < 10 ? '0' + Math.floor(gap / (day)) : Math.floor(gap / day);
            let h = Math.floor((gap % (day)) / (hours)) < 10 ? '0' + Math.floor((gap % (day)) / (hours)) : Math.floor((gap %
                (day)) / (hours));
            let m = Math.floor((gap % (hours)) / (minutes)) < 10 ? '0' + Math.floor((gap % (hours)) / (minutes)) : Math
                .floor((gap % (hours)) / (minutes));
            let s = Math.floor((gap % (minutes)) / (seconds)) < 10 ? '0' + Math.floor((gap % (minutes)) / (seconds)) : Math
                .floor((gap % (minutes)) / (seconds));

            document.querySelector('.days').innerText = d;
            document.querySelector('.hours').innerText = h;
            document.querySelector('.minutes').innerText = m;
            document.querySelector('.seconds').innerText = s;


        }
        setInterval(() => {
            countDown()
        }, 1000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp1\htdocs\Fashion\resources\views/user/design/home.blade.php ENDPATH**/ ?>