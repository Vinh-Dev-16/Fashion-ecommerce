
<?php $__env->startSection('title'); ?>
    Trang Product
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    
    <div class="col-md-12">
        <div class="product">
            <div class="card">
                <div class="card-header">
                    <h2 style="font-size:25px;text-align:center;margin:10px 0">TRANG THÔNG TIN PRODUCT</h2>
                    <h3 class="card-title">
                        <a href="<?php echo e(route('admin.product.create')); ?>">Tạo mới product</a>
                        <span style="margin-left: 20px"><a href="<?php echo e(route('admin.product.viewrestore')); ?>">Restore product</a></span>
                    </h3>
                    <div class="card-tools">
                        <div class="input-group input-group-sm" style="width: 150px;">
                            <input type="text" name="table_search" id="search" class="form-control float-right"
                                placeholder="Search">

                            <div class="input-group-append">
                                <button type="submit" class="btn btn-default">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body table-responsive p-0">
                    <table class="table table-hover text-nowrap">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tên sản phẩm</th>
                                <th>Giá</th>
                                <th>Giảm giá</th>
                                <th>Tồn kho</th>
                                <th>CRUD</th>
                            </tr>
                        </thead>
                        <tbody class="infor_product">
                            <tr>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($product->id); ?></td>
                                    <td><?php echo e(Illuminate\Support\Str::of($product->name)->words(4)); ?></td>
                                    <td><?php echo e(number_format($product->price)); ?> VND</td>
                                    <?php if($product->discount): ?>
                                    <td><?php echo e($product->discount); ?>%</td>
                                    <?php else: ?>
                                    <td>0%</td>   
                                    <?php endif; ?>
                                    <td><?php echo e($product->stock); ?></td>
                                    <td class="table_crud" style="display:flex;justify-content:space-between;width:110px">

                                        <a href="<?php echo e(url('admin/product/edit/' . $product->id)); ?>" title="Sửa Product"
                                            style="border: none;outline:none">
                                            <i class="fa-solid fa-pen" style="color: black; font-size:22px;"></i></a>
                                        <form method="post" action="<?php echo e(url('admin/product/destroy/' . $product->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" title="Xóa Product"
                                                onclick=" return confirm ('Bạn có muốn xóa không?')"
                                                style="border: none;outline:none;padding:0 13px;background:transparent"><i
                                                    class="fa-solid fa-trash"
                                                    style="color: #f4f4f; font-size:22px;"></i></button>
                                        </form>
                                    </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tbody id="search_result"></tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
        <?php echo e($products->links()); ?>

        <div class="item"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcumb'); ?>
    <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard.index')); ?>">Home</a></li>
        <li class="breadcrumb-item active">Products</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    
    <script>
        
        function searchProduct() {
            $(document).ready(function() {
                $("#search").keyup(function() {
                    $input = $(this).val();
                    if ($input) {
                        $('.infor_product').hide();
                        $('#search_result').show();
                    } else {
                        $('.infor_product').show();
                        $('#search_result').hide();
                    }
                    $.ajax({
                        url: "<?php echo e(URL::to('admin/product/search')); ?>",
                        method: "GET",
                        data: {
                            'search': $input
                        },
                        success: function(data) {
                            $("#search_result").html(data);
                        }
                    });
                })
            })
        }
        searchProduct();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\ICT\resources\views/admin/product/index.blade.php ENDPATH**/ ?>