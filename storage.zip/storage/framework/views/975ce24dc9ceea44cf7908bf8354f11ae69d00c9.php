
<?php $__env->startSection('title'); ?>
    Lịch sử mua hàng
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(App\Models\Order::where('user_id', Auth::user()->id)): ?>
        <div class="single_checkout">
            <div class="container">
                <div class="wrapper">
                    <div class="breadcrumb">
                        <ul class="flexitem">
                            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li>Lịch sử giao dịch</li>
                        </ul>
                    </div>
                    <div class="main_history">
                        <div class="switch_tabs">
                            <ul class="tabs">
                                <li>
                                    <i class="ri-check-fill"></i> Chờ xác nhận
                                </li>
                                <li>
                                    <i class="ri-truck-line"></i> Đang giao hàng
                                </li>
                                <li>
                                    <i class="ri-checkbox-multiple-line"></i> Đã giao hàng
                                </li>
                                <li>
                                    <i class="ri-close-line"></i>Đã hủy hàng
                                </li>
                            </ul>

                            <div class="container_tabs ">
                                <div class="content_tabs active">
                                    <div class="products one cart">
                                        <div class="item" style="width: 100%">
                                            <table id="cart_table">
                                                <thead>
                                                    <tr>
                                                        <th>Sản phẩm</th>
                                                        <th>Giá</th>
                                                        <th>Số lượng</th>
                                                        <th>Tổng tiền</th>
                                                        <th>Thao tác</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = App\Models\Order::where('user_id', Auth::user()->id)->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($orderItem->status == 0): ?>
                                                                <tr>
                                                                    <td class="flexitem">
                                                                        <?php if($orderItem->sale == 0): ?>
                                                                            <div class="thumbnail">
                                                                                <a
                                                                                    href="<?php echo e(url('detail/' . $orderItem->product_id)); ?>"><img
                                                                                        src="<?php echo e($orderItem->product->images->first()->path); ?>"
                                                                                        alt="<?php echo e($orderItem->name); ?>"></a>
                                                                            </div>
                                                                            <div class="content">
                                                                                <strong>
                                                                                    <a
                                                                                        href="<?php echo e(url('detail/' . $orderItem->product_id)); ?>"><?php echo e($orderItem->name); ?>

                                                                                    </a>
                                                                                </strong>
                                                                                <p style="margin-bottom: 1px">Color:
                                                                                    <?php echo e($orderItem->color); ?></p>
                                                                                <p>Size: <?php echo e($orderItem->size); ?></p>
                                                                            </div>
                                                                        <?php else: ?>
                                                                            <div class="thumbnail">
                                                                                <a
                                                                                    href="<?php echo e(url('pageoffer/' . $orderItem->product_id)); ?>"><img
                                                                                        src="<?php echo e($orderItem->product->images->first()->path); ?>"
                                                                                        alt="<?php echo e($orderItem->name); ?>"></a>
                                                                            </div>
                                                                            <div class="content">
                                                                                <strong>
                                                                                    <a
                                                                                        href="<?php echo e(url('pageoffer/' . $orderItem->product_id)); ?>"><?php echo e($orderItem->name); ?>

                                                                                    </a>
                                                                                </strong>
                                                                                <p style="margin-bottom: 1px">Color:
                                                                                    <?php echo e($orderItem->color); ?></p>
                                                                                <p>Size: <?php echo e($orderItem->size); ?></p>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php if($orderItem->discount): ?>
                                                                            <span><?php echo e(number_format($orderItem->price - ($orderItem->discount / 100) * $orderItem->price)); ?>

                                                                                VND
                                                                            </span>
                                                                        <?php else: ?>
                                                                            <span>
                                                                                <?php echo e(number_format($orderItem->price)); ?>

                                                                                VND
                                                                            </span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td><?php echo e($orderItem->quantity); ?></td>
                                                                    <td>
                                                                        <?php echo e(number_format($orderItem->total_money)); ?> VND
                                                                    </td>
                                                                    <td>
                                                                        <a href="<?php echo e(url('softdelete/' . $orderItem->id)); ?>">Hủy
                                                                            đơn</a>
                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="content_tabs">
                                    <div class="products one cart">
                                        <div class="item" style="width: 100%">
                                            <table id="cart_table" style="margin-top: 30px">
                                                <thead>
                                                    <tr>
                                                        <th>Sản phẩm</th>
                                                        <th>Giá</th>
                                                        <th>Số lượng</th>
                                                        <th>Tổng tiền</th>
                                                        <th>Thao tác</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = App\Models\Order::where('user_id', Auth::user()->id)->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($orderItem->status == 2): ?>
                                                                <tr>
                                                                    <td class="flexitem">
                                                                        <?php if($orderItem->sale == 0): ?>
                                                                            <div class="thumbnail">
                                                                                <a
                                                                                    href="<?php echo e(url('detail/' . $orderItem->product_id)); ?>"><img
                                                                                        src="<?php echo e($orderItem->product->images->first()->path); ?>"
                                                                                        alt="<?php echo e($orderItem->name); ?>"></a>
                                                                            </div>
                                                                            <div class="content">
                                                                                <strong>
                                                                                    <a
                                                                                        href="<?php echo e(url('detail/' . $orderItem->product_id)); ?>"><?php echo e($orderItem->name); ?>

                                                                                    </a>
                                                                                </strong>
                                                                                <p style="margin-bottom: 1px">Color:
                                                                                    <?php echo e($orderItem->color); ?></p>
                                                                                <p>Size: <?php echo e($orderItem->size); ?></p>
                                                                            </div>
                                                                        <?php else: ?>
                                                                            <div class="thumbnail">
                                                                                <a
                                                                                    href="<?php echo e(url('pageoffer/' . $orderItem->product_id)); ?>"><img
                                                                                        src="<?php echo e($orderItem->product->images->first()->path); ?>"
                                                                                        alt="<?php echo e($orderItem->name); ?>"></a>
                                                                            </div>
                                                                            <div class="content">
                                                                                <strong>
                                                                                    <a
                                                                                        href="<?php echo e(url('pageoffer/' . $orderItem->product_id)); ?>"><?php echo e($orderItem->name); ?>

                                                                                    </a>
                                                                                </strong>
                                                                                <p style="margin-bottom: 1px">Color:
                                                                                    <?php echo e($orderItem->color); ?></p>
                                                                                <p>Size: <?php echo e($orderItem->size); ?></p>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php if($orderItem->discount): ?>
                                                                            <span><?php echo e(number_format($orderItem->price - ($orderItem->discount / 100) * $orderItem->price)); ?>

                                                                                VND
                                                                            </span>
                                                                        <?php else: ?>
                                                                            <span>
                                                                                <?php echo e(number_format($orderItem->price)); ?>

                                                                                VND
                                                                            </span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td><?php echo e($orderItem->quantity); ?></td>
                                                                    <td>
                                                                        <?php echo e(number_format($orderItem->total_money)); ?> VND
                                                                    </td>
                                                                    <td>
                                                                        <div style="cursor: pointer" class="detail_ship">Xem
                                                                            chi
                                                                            tiết</div>
                                                                        <br>
                                                                        <?php if($orderItem->ship == 1): ?>
                                                                            <a
                                                                                href="<?php echo e(url('confirm/product/' . $orderItem->id)); ?>">Confirm</a>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <div class="main_ship">
                                                                    <h3 class="heading_ship">Trạng thái giao hàng</h3>

                                                                    <div class="container_ship">
                                                                        <ul>
                                                                            <?php if($orderItem->ship == 1): ?>
                                                                                <li>
                                                                                    <h3 class="title">Đã giao hàng</h3>
                                                                                    <p>Đơn hàng của bạn đã được shipper giao
                                                                                        tới. Vui lòng mời bạn xuống nhận</p>
                                                                                    <span class="circle_ship"></span>
                                                                                    <span
                                                                                        class="date"><?php echo e(date('d-m-Y'), strtotime($orderItem->time)); ?></span>
                                                                                </li>
                                                                            <?php endif; ?>
                                                                            <li>
                                                                                <h3 class="title">Đang giao hàng</h3>
                                                                                <p>Đơn hàng của bạn đang được giao</p>
                                                                                <span class="circle_ship"></span>
                                                                                <span class="date">
                                                                                    <?php echo e(date('d-m-Y'), strtotime($orderItem->time_confirm)); ?></span>
                                                                            </li>
                                                                            <li>
                                                                                <h3 class="title">Đã đóng hàng</h3>
                                                                                <p>Đơn hàng của bạn đã được nhà cung cấp
                                                                                    đóng hàng vào ngày
                                                                                    <?php echo e(date('d-m-Y'), strtotime($orderItem->time)); ?>

                                                                                </p>
                                                                                <span class="circle_ship"></span>
                                                                                <span class="date">
                                                                                    <?php echo e(date('d-m-Y'), strtotime($orderItem->time_confirm)); ?>

                                                                                </span>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                    <div class="overlay"></div>
                                                                </div>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                </div>
                                <div class="content_tabs">
                                    <div class="products one cart">
                                        <div class="item" style="width: 100%">
                                            <table id="cart_table">
                                                <thead>
                                                    <tr>
                                                        <th>Sản phẩm</th>
                                                        <th>Giá</th>
                                                        <th>Số lượng</th>
                                                        <th>Tổng tiền</th>
                                                        <th>Ngày nhận hàng</th>
                                                        <th>Thao tác</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = App\Models\Order::where('user_id', Auth::user()->id)->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($orderItem->status == 1): ?>
                                                                <tr>
                                                                    <td class="flexitem">
                                                                        <?php if($orderItem->sale == 0): ?>
                                                                            <div class="thumbnail">
                                                                                <a
                                                                                    href="<?php echo e(url('detail/' . $orderItem->product_id)); ?>"><img
                                                                                        src="<?php echo e($orderItem->product->images->first()->path); ?>"
                                                                                        alt="<?php echo e($orderItem->name); ?>"></a>
                                                                            </div>
                                                                            <div class="content">
                                                                                <strong>
                                                                                    <a
                                                                                        href="<?php echo e(url('detail/' . $orderItem->product_id)); ?>"><?php echo e($orderItem->name); ?>

                                                                                    </a>
                                                                                </strong>
                                                                                <p style="margin-bottom: 1px">Color:
                                                                                    <?php echo e($orderItem->color); ?></p>
                                                                                <p>Size: <?php echo e($orderItem->size); ?></p>
                                                                            </div>
                                                                        <?php else: ?>
                                                                            <div class="thumbnail">
                                                                                <a
                                                                                    href="<?php echo e(url('pageoffer/' . $orderItem->product_id)); ?>"><img
                                                                                        src="<?php echo e($orderItem->product->images->first()->path); ?>"
                                                                                        alt="<?php echo e($orderItem->name); ?>"></a>
                                                                            </div>
                                                                            <div class="content">
                                                                                <strong>
                                                                                    <a
                                                                                        href="<?php echo e(url('pageoffer/' . $orderItem->product_id)); ?>"><?php echo e($orderItem->name); ?>

                                                                                    </a>
                                                                                </strong>
                                                                                <p style="margin-bottom: 1px">Color:
                                                                                    <?php echo e($orderItem->color); ?></p>
                                                                                <p>Size: <?php echo e($orderItem->size); ?></p>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php if($orderItem->discount): ?>
                                                                            <span><?php echo e(number_format($orderItem->price - ($orderItem->discount / 100) * $orderItem->price)); ?>

                                                                                VND
                                                                            </span>
                                                                        <?php else: ?>
                                                                            <span>
                                                                                <?php echo e(number_format($orderItem->price)); ?>

                                                                                VND
                                                                            </span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td><?php echo e($orderItem->quantity); ?></td>
                                                                    <td>
                                                                        <?php echo e(number_format($orderItem->total_money)); ?> VND
                                                                    </td>
                                                                    <td> <?php echo e(date('d-m-Y'), strtotime($order->updated_at)); ?>

                                                                    </td>
                                                                    <td class="history_ship" style="cursor: pointer">Xem
                                                                        lịch sử</td>
                                                                </tr>
                                                                <div class="history">
                                                                    <h3 class="heading_ship">Trạng thái giao hàng</h3>

                                                                    <div class="container_ship">
                                                                        <ul>
                                                                            <li>
                                                                                <h3 class="title">Đã nhận được hàng</h3>
                                                                                <p>Bạn đã nhận được hàng</p>
                                                                                <span class="circle_ship"></span>
                                                                                <span
                                                                                    class="date"><?php echo e(date('d-m-Y'), strtotime($orderItem->updated_at)); ?></span>
                                                                            </li>
                                                                            <li>
                                                                                <h3 class="title">Đã giao hàng</h3>
                                                                                <p>Đơn hàng của bạn đã được shipper giao
                                                                                    tới. Vui lòng mời bạn xuống nhận</p>
                                                                                <span class="circle_ship"></span>
                                                                                <span
                                                                                    class="date"><?php echo e(date('d-m-Y'), strtotime($orderItem->time)); ?></span>
                                                                            </li>
                                                                            <li>
                                                                                <h3 class="title">Đang giao hàng</h3>
                                                                                <p>Đơn hàng của bạn đang được giao</p>
                                                                                <span class="circle_ship"></span>
                                                                                <span class="date">
                                                                                    <?php echo e(date('d-m-Y'), strtotime($orderItem->time_confirm)); ?></span>
                                                                            </li>
                                                                            <li>
                                                                                <h3 class="title">Đã đóng hàng</h3>
                                                                                <p>Đơn hàng của bạn đã được nhà cung cấp
                                                                                    đóng hàng vào ngày
                                                                                    <?php echo e(date('d-m-Y'), strtotime($orderItem->time)); ?>

                                                                                </p>
                                                                                <span class="circle_ship"></span>
                                                                                <span class="date">
                                                                                    <?php echo e(date('d-m-Y'), strtotime($orderItem->time_confirm)); ?>

                                                                                </span>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                    <div class="overlay"></div>
                                                                </div>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="content_tabs">
                                    <div class="products one cart">
                                        <div class="item" style="width: 100%">
                                            <table id="cart_table">
                                                <thead>
                                                    <tr>
                                                        <th>Sản phẩm</th>
                                                        <th>Giá</th>
                                                        <th>Số lượng</th>
                                                        <th>Tổng tiền</th>
                                                        <th>Thao tác</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = App\Models\Order::where('user_id', Auth::user()->id)->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = App\Models\OrderDetail::onlyTrashed()->where('order_id' , $order->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($orderItem->status == 0): ?>
                                                                <tr>
                                                                    <td class="flexitem">
                                                                        <?php if($orderItem->sale == 0): ?>
                                                                            <div class="thumbnail">
                                                                                <a
                                                                                    href="<?php echo e(url('detail/' . $orderItem->product_id)); ?>"><img
                                                                                        src="<?php echo e($orderItem->product->images->first()->path); ?>"
                                                                                        alt="<?php echo e($orderItem->name); ?>"></a>
                                                                            </div>
                                                                            <div class="content">
                                                                                <strong>
                                                                                    <a
                                                                                        href="<?php echo e(url('detail/' . $orderItem->product_id)); ?>"><?php echo e($orderItem->name); ?>

                                                                                    </a>
                                                                                </strong>
                                                                                <p style="margin-bottom: 1px">Color:
                                                                                    <?php echo e($orderItem->color); ?></p>
                                                                                <p>Size: <?php echo e($orderItem->size); ?></p>
                                                                            </div>
                                                                        <?php else: ?>
                                                                            <div class="thumbnail">
                                                                                <a
                                                                                    href="<?php echo e(url('pageoffer/' . $orderItem->product_id)); ?>"><img
                                                                                        src="<?php echo e($orderItem->product->images->first()->path); ?>"
                                                                                        alt="<?php echo e($orderItem->name); ?>"></a>
                                                                            </div>
                                                                            <div class="content">
                                                                                <strong>
                                                                                    <a
                                                                                        href="<?php echo e(url('pageoffer/' . $orderItem->product_id)); ?>"><?php echo e($orderItem->name); ?>

                                                                                    </a>
                                                                                </strong>
                                                                                <p style="margin-bottom: 1px">Color:
                                                                                    <?php echo e($orderItem->color); ?></p>
                                                                                <p>Size: <?php echo e($orderItem->size); ?></p>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php if($orderItem->discount): ?>
                                                                            <span><?php echo e(number_format($orderItem->price - ($orderItem->discount / 100) * $orderItem->price)); ?>

                                                                                VND
                                                                            </span>
                                                                        <?php else: ?>
                                                                            <span>
                                                                                <?php echo e(number_format($orderItem->price)); ?>

                                                                                VND
                                                                            </span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td><?php echo e($orderItem->quantity); ?></td>
                                                                    <td>
                                                                        <?php echo e(number_format($orderItem->total_money)); ?> VND
                                                                    </td>
                                                                    <td>
                                                                        <a href="<?php echo e(url('restore/' . $orderItem->id)); ?>">Đặt
                                                                            lại </a>
                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <h2 class="search_page">Bạn chưa có đơn hàng nào</h2>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>
        const dpt_menu = document.querySelectorAll('.dpt_menu');
        const close_menu = document.querySelectorAll('#close_menu');

        for (let i of dpt_menu) {
            i.classList.add('active');
        }
        close_menu.forEach((item) => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                for (let i of dpt_menu) {
                    i.classList.toggle('active');
                }
            });
        })

        const tabs = document.querySelectorAll(".tabs li");
        const content = document.querySelectorAll(".content_tabs");

        tabs.forEach((tab, index) => {
            tab.addEventListener("click", () => {
                tabs.forEach((tab) => tab.classList.remove("active"));

                tab.classList.add("active");
                content.forEach(c => c.classList.remove("active"));
                content[index].classList.add('active');
            });
        });
        tabs[0].click();

        let detail_ship = document.querySelectorAll('.detail_ship');
        let main_ship = document.querySelectorAll('.main_ship');

        detail_ship.forEach((tab, index) => {
            tab.addEventListener("click", () => {
                main_ship.forEach(c => c.classList.remove("active"));
                main_ship[index].classList.toggle('active');
            });
        });

        let history_ship = document.querySelectorAll('.history_ship');
        let history = document.querySelectorAll('.history');

        history_ship.forEach((tab, index) => {
            tab.addEventListener("click", () => {
                main_ship.forEach(c => c.classList.remove("active"));
                history[index].classList.toggle('active');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp1\htdocs\Fashion\resources\views/user/design/history.blade.php ENDPATH**/ ?>